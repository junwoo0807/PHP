

// ���� ����

	document.getElementById("sub_course_004").src = '../images/sub_down.gif';
	document.getElementById("sub_title_004").style.fontWeight='bold';

// ���� ��




//���Ѹ���Ʈ ����


	function all_check() {      
		
		var len = document.pagesize_form.chk.length;
		var chk = document.pagesize_form.chk; 

		if (len != '0')	{
		
			for ( var i=2;i<len; i++ ) {
				
				chk[i].checked = !chk[i].checked;
				tr_check(i);
			
			}
		}

	}




	function tr_check(num) {   
		
		var i = num; 
		var pf = document.pagesize_form;

		pf.pi_resultAu[i].checked = !pf.pi_resultAu[i].checked;
		pf.pi_pollAu[i].checked = !pf.pi_pollAu[i].checked;
		pf.pi_commentAu[i].checked = !pf.pi_commentAu[i].checked;
		pf.pi_iconAu[i].checked = !pf.pi_iconAu[i].checked;
		pf.pi_pictureAu[i].checked = !pf.pi_pictureAu[i].checked;

	}


	function resultAu_check() {      
		
		var len = document.pagesize_form.pi_resultAu.length;
		var pi_resultAu = document.pagesize_form.pi_resultAu; 

		if (len != '0')	{
		
			for ( var i=2;i<len; i++ ) {
				pi_resultAu[i].checked = !pi_resultAu[i].checked;
			}
		}

	}


	function pollAu_check() {      
		
		var len = document.pagesize_form.pi_pollAu.length;
		var pi_pollAu = document.pagesize_form.pi_pollAu; 

		if (len != '0')	{
		
			for ( var i=2;i<len; i++ ) {
				pi_pollAu[i].checked = !pi_pollAu[i].checked;
			}
		}

	}


	function commentAu_check() {      
		
		var len = document.pagesize_form.pi_commentAu.length;
		var pi_commentAu = document.pagesize_form.pi_commentAu; 

		if (len != '0')	{
		
			for ( var i=2;i<len; i++ ) {
				pi_commentAu[i].checked = !pi_commentAu[i].checked;
			}
		}

	}


	function iconAu_check() {      
		
		var len = document.pagesize_form.pi_iconAu.length;
		var pi_iconAu = document.pagesize_form.pi_iconAu; 

		if (len != '0')	{
		
			for ( var i=2;i<len; i++ ) {
				pi_iconAu[i].checked = !pi_iconAu[i].checked;
			}
		}

	}


	function pictureAu_check() {      
		
		var len = document.pagesize_form.pi_pictureAu.length;
		var pi_pictureAu = document.pagesize_form.pi_pictureAu; 

		if (len != '0')	{
		
			for ( var i=2;i<len; i++ ) {
				pi_pictureAu[i].checked = !pi_pictureAu[i].checked;
			}
		}

	}



function sendit_1(){

	if (confirm("ȸ���� ���Ѽ����� �����Ͻðڽ��ϱ�?")) {
		
	}
	else {
		alert("������ ��ҵǾ����ϴ�.");
		return false;
	}

	document.pagesize_form.submit();
}


//���Ѹ���Ʈ ��
