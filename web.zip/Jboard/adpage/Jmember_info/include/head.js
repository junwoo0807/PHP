




	document.getElementById("sub_menu_001").style.display = 'block';
	document.getElementById("sub_course_001").src = '../images/sub_down.gif';
	document.getElementById("sub_vaginal_001").src = '../images/sub_minus.gif';
	document.getElementById("sub_title_001").style.fontWeight='bold';






	function sendit_3(sort_name) {

		var af = document.add_form;

		if (af.he_name.value == "") {
			alert("�ش� "+sort_name+"��(��) �Է����ּ���.");
			af.he_name.focus();
			return false;
		}


		af.action = "head_write_pro.asp"; 
		af.method = "post";

	}



	function sendit_4() {

		var lf = document.list_form;

		lf.action = "head_modify_pro.asp"; 
		lf.method = "post";
		lf.submit();

	}


	function del(urlpath, ji_name){

		if (confirm(ji_name+"��(��) �����Ͻðڽ��ϱ�?")) {
			
			location.href(urlpath);
		}
		else {
			alert("������ ��ҵǾ����ϴ�.");
		}
	}

