
	
	
	function iframe_H(FormName, InputName, file_name) {
		var FormName, InputName;

		InputName = eval('parent.document.'+FormName+'.'+InputName);
		InputName.value = file_name;
	
		parent.source_view();

	}


	function page_linkFindFile(FormName, InputName, f_prev, r_name, r_folder, l_folder, last) {
		var targetSTR;
		var pf = document.iframeDir;

		pf.FormName.value	  = FormName;
		pf.InputName.value  = InputName;
		pf.f_location.value	= f_prev;
		pf.r_location.value	= r_name;
		pf.r_folder.value   = r_folder;
		pf.l_folder.value   = l_folder;
		pf.last.value			  = last;

		pf.method = 'post'
		pf.action = 'iframe_directory.asp';
		pf.submit();

	}
