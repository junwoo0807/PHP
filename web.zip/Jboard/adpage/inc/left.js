


	function submenu(obj, menu, course, vaginal, title) {

		obj.style.cursor = "hand";

		sub_menu = document.getElementById(menu);
		sub_course = document.getElementById(course);
		sub_vaginal = document.getElementById(vaginal);
		sub_title = document.getElementById(title);



		if (sub_menu.style.display == "none") {
			sub_menu.style.display = "block";
			sub_course.src = '../../adpage/images/sub_down.gif';
			sub_vaginal.src = '../../adpage/images/sub_minus.gif';
			sub_title.style.fontWeight='bold';
		}
		else{
			sub_menu.style.display = "none";
			sub_course.src = '../../adpage/images/sub_side.gif';
			sub_vaginal.src = '../../adpage/images/sub_plus.gif';
			sub_title.style.fontWeight='';
		}
	}






	function endmenu(obj, course, title) {

		obj.style.cursor = "hand";

		sub_title = document.getElementById(title);
		sub_course = document.getElementById(course);



		if (sub_title.style.display == "") {
			sub_course.src = '../../adpage/images/sub_down.gif';
			sub_title.style.fontWeight='bold';
		}
		else{
			sub_course.src = '../../adpage/images/sub_side.gif';
			sub_title.style.fontWeight='';
		}
	}

