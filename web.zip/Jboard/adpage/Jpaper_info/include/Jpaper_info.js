

// ���� ����


	function allblur() {
		for (i = 0; i < document.links.length; i++)
			document.links[i].onfocus = document.links[i].blur;
	}

	//window.onload = allblur;



	function reset() {
		for (i = 0; i < document.forms.length; i++)
			document.forms[i].value = document.forms[i].reset();
	}



	function onlyNumber() {
		if((event.keyCode<48)||(event.keyCode>57))
		event.returnValue=false;
	}




	function OnClickTR_2(){

		if (document.getElementById("Jpaper_info_write_tr_2").style.display == "none") {
			document.getElementById("Jpaper_info_write_tr_2").style.display = "block";
			document.getElementById("Jpaper_info_write_tr_3").style.display = "block";
			document.getElementById("Jpaper_info_write_tr_4").style.display = "block";
			document.getElementById("Jpaper_info_write_tr_5").style.display = "block";
			document.getElementById("Jpaper_info_write_tr_6").style.display = "none";
			document.getElementById("Jpaper_info_write_tr_7").style.display = "none";
		}	else {
			document.getElementById("Jpaper_info_write_tr_2").style.display = "none";
			document.getElementById("Jpaper_info_write_tr_3").style.display = "none";
			document.getElementById("Jpaper_info_write_tr_4").style.display = "none";
			document.getElementById("Jpaper_info_write_tr_5").style.display = "none";
		}

	}


	function OnClickTR_3(){

		if (document.getElementById("Jpaper_info_write_tr_6").style.display == "none") {
			document.getElementById("Jpaper_info_write_tr_6").style.display = "block";
			document.getElementById("Jpaper_info_write_tr_7").style.display = "block";
			document.getElementById("Jpaper_info_write_tr_2").style.display = "none";
			document.getElementById("Jpaper_info_write_tr_3").style.display = "none";
			document.getElementById("Jpaper_info_write_tr_4").style.display = "none";
			document.getElementById("Jpaper_info_write_tr_5").style.display = "none";
		}	else {
			document.getElementById("Jpaper_info_write_tr_6").style.display = "none";
			document.getElementById("Jpaper_info_write_tr_7").style.display = "none";
		}

	}


	function OnClickTR_4(){

		document.getElementById("Jpaper_info_write_tr_6").style.display = "none";
		document.getElementById("Jpaper_info_write_tr_7").style.display = "none";
		document.getElementById("Jpaper_info_write_tr_2").style.display = "none";
		document.getElementById("Jpaper_info_write_tr_3").style.display = "none";
		document.getElementById("Jpaper_info_write_tr_4").style.display = "none";
		document.getElementById("Jpaper_info_write_tr_5").style.display = "none";

	}



	document.getElementById("sub_menu_010").style.display = 'block';
	document.getElementById("sub_course_010").src = '../images/sub_down.gif';
	document.getElementById("sub_vaginal_010").src = '../images/sub_minus.gif';
	document.getElementById("sub_title_010").style.fontWeight='bold';

// ���� ��






// MODIFY �� ����


	if(window.XMLHttpRequest) {
		xmlRequest = new XMLHttpRequest();
	} else { 
		xmlRequest = new ActiveXObject("Microsoft.XMLHTTP");
	} 

	function ajax_skinColor() {

		var jiwf = document.Jpaper_info_modify_form;
		
		ji_skinname = jiwf.ji_skinname.value;


		var url = "include/ajax_skinColorPro.asp?ji_skinname="+escape(ji_skinname);
		xmlRequest.open("GET",url,true);
		xmlRequest.onreadystatechange = skinColor;
		xmlRequest.send(null);

	}

	function skinColor() {
				
		if (xmlRequest.readyState ==4){
			var ji_skinColor = xmlRequest.responseText;
			document.getElementById("ji_skinColor").innerHTML = ji_skinColor;
		}
	}




	function opt_ins_modi(n){
		var obj1,obj2,len

		if (n == "1"){
			obj1 = document.Jpaper_info_modify_form.opt1_size;
			obj2 = document.Jpaper_info_modify_form.opt1_list;
		}else{//n=="2"
			obj1 = document.Jpaper_info_modify_form.opt2_size;
			obj2 = document.Jpaper_info_modify_form.opt2_list;
		}

		if(obj1.value.length < 1) {
			alert("�ɼǳ����� �Է��Ͽ��� �մϴ�.");
			obj1.focus();
			return;
		}

		len = obj2.length;
		obj2.length = len+1;
		obj2.options[len].value = obj1.value;
		obj2.options[len].text = obj1.value;
		obj1.value="";
		obj1.focus();
	}



	function opt_del_modi(n){

			if (n == "1"){
				var obj = document.Jpaper_info_modify_form.opt1_list;
			}else{//n=="2"
				var obj = document.Jpaper_info_modify_form.opt2_list;
			}
			var now_seq = obj.selectedIndex;//���� ����Ʈ ��ü
			if (now_seq==-1){
				alert("�ɼ��� �����ϼ���.");
				return;
			}
			obj.options[obj.selectedIndex]=null;
	}






	function registInfo(ji_name) {

		var jiwf = document.Jpaper_info_modify_form;
		var listArray = new Array(jiwf.opt1_list,jiwf.opt2_list);
		var i, j

		var FormLimit = 4000
		var PrefaceVar = new String
		var RearVar = new String

    var select_check1;
		var len = jiwf.ji_skinColor.length;

		if (len > 0) {		

			for(i=0; i < len; i++) {
				if(jiwf.ji_skinColor[i].checked) { 
					select_check1=jiwf.ji_skinColor[i].value; 
					break;
				}
			}

		} else {
			if(jiwf.ji_skinColor.checked) { 
				select_check1=jiwf.ji_skinColor.value; 
			}
		}

    if(!select_check1) { 
      alert("��Ų�÷��� ������ �ּ���.");
      return;
    }

		if (jiwf.ji_width[0].value == '') {	
			alert("������ ���̸� �Է����ּ���");
			jiwf.ji_width[0].focus();
			return;
		}


		if (confirm(ji_name+" ���������� �����Ͻðڽ��ϱ�?")) {

			for (i=0;i<2;i++){
					
				for(j=0;j<listArray[i].length;j++){
					listArray[i].options[j].selected = true;
				}
			}


			PrefaceVar = jiwf.ji_preface.value

			if (PrefaceVar.length > FormLimit) {
				jiwf.ji_preface.value = PrefaceVar.substr(0, FormLimit)
				PrefaceVar = PrefaceVar.substr(FormLimit)

				while (PrefaceVar.length > 0) {
					var PrefaceTextArea = document.createElement("TEXTAREA")
					PrefaceTextArea.name = "ji_preface"
					PrefaceTextArea.value = PrefaceVar.substr(0, FormLimit)
					jiwf.appendChild(PrefaceTextArea)

					PrefaceVar = PrefaceVar.substr(FormLimit)
				}
			}

			
			RearVar = jiwf.ji_rear.value    

			if (RearVar.length > FormLimit) {
				jiwf.ji_rear.value = RearVar.substr(0, FormLimit)
				RearVar = RearVar.substr(FormLimit)

				while (RearVar.length > 0) {
					var RearTextArea = document.createElement("TEXTAREA")
					RearTextArea.name = "ji_rear"
					RearTextArea.value = RearVar.substr(0, FormLimit)
					jiwf.appendChild(RearTextArea)

					RearVar = RearVar.substr(FormLimit)
				}
			}


			jiwf.action = "Jpaper_info_modify_pro.asp";
			jiwf.method = "post";
			//jiwf.target = "HiddenFm";
			jiwf.submit();



		} else {
			alert("������ ��ҵǾ����ϴ�.");
			return;
		}

	}


// MODIFY �� ��



// ���������� �� ����


	function sendPaper() {

		var pf = document.Jpaper_form;
		
		if (pf.pa_receiveMeId.value == '') {	
			alert("�޴��̸� �������ּ���");
			pf.pa_receiveMeId.focus();
			return;
		}


		if (pf.pa_content.value == '') {	
			alert("���ϳ����� �Է����ּ���");
			pf.pa_content.focus();
			return;
		}

    for ( var i = 0; i < pf.pa_receiveMeId.length; i++ ) {
      if ( pf.pa_receiveMeId[i].selected == true ) {
        receiveSort = pf.pa_receiveMeId[i].text;
      }
    }

		if (confirm("�Է��Ͻ� ������ �߼��Ͻðڽ��ϱ�?")) {

			pf.action = "Jpaper_send_pro.asp?receiveSort="+receiveSort;
			pf.method = "post";
			//pf.target = "HiddenFm";
			pf.submit();



		} else {
			alert("�߼��� ��ҵǾ����ϴ�.");
			return;
		}

	}


// ���������� �� ��
