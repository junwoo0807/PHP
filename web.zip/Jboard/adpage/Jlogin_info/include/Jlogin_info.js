

// ���� ����


	function allblur() {
		for (i = 0; i < document.links.length; i++)
			document.links[i].onfocus = document.links[i].blur;
	}

	//window.onload = allblur;



	function reset() {
		for (i = 0; i < document.forms.length; i++)
			document.forms[i].value = document.forms[i].reset();
	}



	function onlyNumber() {
		if((event.keyCode<48)||(event.keyCode>57))
		event.returnValue=false;
	}





	function OnClickTR_2(){

		if (document.getElementById("Jlogin_info_write_tr_2").style.display == "none") {
			document.getElementById("Jlogin_info_write_tr_2").style.display = "block";
			document.getElementById("Jlogin_info_write_tr_3").style.display = "block";
			document.getElementById("Jlogin_info_write_tr_4").style.display = "block";
			document.getElementById("Jlogin_info_write_tr_5").style.display = "block";
			document.getElementById("Jlogin_info_write_tr_6").style.display = "none";
			document.getElementById("Jlogin_info_write_tr_7").style.display = "none";
		}	else {
			document.getElementById("Jlogin_info_write_tr_2").style.display = "none";
			document.getElementById("Jlogin_info_write_tr_3").style.display = "none";
			document.getElementById("Jlogin_info_write_tr_4").style.display = "none";
			document.getElementById("Jlogin_info_write_tr_5").style.display = "none";
		}

	}


	function OnClickTR_3(){

		if (document.getElementById("Jlogin_info_write_tr_6").style.display == "none") {
			document.getElementById("Jlogin_info_write_tr_6").style.display = "block";
			document.getElementById("Jlogin_info_write_tr_7").style.display = "block";
			document.getElementById("Jlogin_info_write_tr_2").style.display = "none";
			document.getElementById("Jlogin_info_write_tr_3").style.display = "none";
			document.getElementById("Jlogin_info_write_tr_4").style.display = "none";
			document.getElementById("Jlogin_info_write_tr_5").style.display = "none";
		}	else {
			document.getElementById("Jlogin_info_write_tr_6").style.display = "none";
			document.getElementById("Jlogin_info_write_tr_7").style.display = "none";
		}

	}


	function OnClickTR_4(){

		document.getElementById("Jlogin_info_write_tr_6").style.display = "none";
		document.getElementById("Jlogin_info_write_tr_7").style.display = "none";
		document.getElementById("Jlogin_info_write_tr_2").style.display = "none";
		document.getElementById("Jlogin_info_write_tr_3").style.display = "none";
		document.getElementById("Jlogin_info_write_tr_4").style.display = "none";
		document.getElementById("Jlogin_info_write_tr_5").style.display = "none";

	}



	document.getElementById("sub_menu_002").style.display = 'block';
	document.getElementById("sub_course_002").src = '../images/sub_down.gif';
	document.getElementById("sub_vaginal_002").src = '../images/sub_minus.gif';
	document.getElementById("sub_title_002").style.fontWeight='bold';

// ���� ��
















// MODIFY �� ����


	if(window.XMLHttpRequest) {
		xmlRequest = new XMLHttpRequest();
	} else { 
		xmlRequest = new ActiveXObject("Microsoft.XMLHTTP");
	} 

	function ajax_skinColor() {

		var jiwf = document.Jlogin_info_modify_form;
		
		ji_skinname = jiwf.ji_skinname.value;


		var url = "include/ajax_skinColorPro.asp?ji_skinname="+escape(ji_skinname);
		xmlRequest.open("GET",url,true);
		xmlRequest.onreadystatechange = skinColor;
		xmlRequest.send(null);

	}

	function skinColor() {
				
		if (xmlRequest.readyState ==4){
			var ji_skinColor = xmlRequest.responseText;
			document.getElementById("ji_skinColor").innerHTML = ji_skinColor;
		}
	}



	function registInfo(ji_name) {

		var jiwf = document.Jlogin_info_modify_form;
		var FormLimit = 4000
		var PrefaceVar = new String
		var RearVar = new String

    var select_check1;
		var len = jiwf.ji_skinColor.length;

		if (len > 0) {		

			for(i=0; i < len; i++) {
				if(jiwf.ji_skinColor[i].checked) { 
					select_check1=jiwf.ji_skinColor[i].value; 
					break;
				}
			}

		} else {
			if(jiwf.ji_skinColor.checked) { 
				select_check1=jiwf.ji_skinColor.value; 
			}
		}

    if(!select_check1) { 
      alert("��Ų�÷��� ������ �ּ���.");
      return;
    }

		if (jiwf.ji_listChoice[0].checked && jiwf.ji_listChoice[1].checked) {	
			alert("\'�ڵ��α���\'�� \'ID����\'�� ���ÿ� ����Ͻ� �� �����ϴ�.\n\n�� �� �ϳ��� �����մϴ�.");
			jiwf.ji_listChoice[0].focus();
			return;
		}

		if (jiwf.ji_width[0].value == '') {	
			alert("�α����� ���̸� �Է����ּ���");
			jiwf.ji_width[0].focus();
			return;
		}

		if (jiwf.ji_width[0].value == 0) {	
			alert("�α����� ���̴� 0���� Ŀ���մϴ�.");
			jiwf.ji_width[0].focus();
			return;
		}

		if (confirm(ji_name+" ���������� �����Ͻðڽ��ϱ�?")) {

			PrefaceVar = jiwf.ji_preface.value

			if (PrefaceVar.length > FormLimit) {
				jiwf.ji_preface.value = PrefaceVar.substr(0, FormLimit)
				PrefaceVar = PrefaceVar.substr(FormLimit)

				while (PrefaceVar.length > 0) {
					var PrefaceTextArea = document.createElement("TEXTAREA")
					PrefaceTextArea.name = "ji_preface"
					PrefaceTextArea.value = PrefaceVar.substr(0, FormLimit)
					jiwf.appendChild(PrefaceTextArea)

					PrefaceVar = PrefaceVar.substr(FormLimit)
				}
			}

			
			RearVar = jiwf.ji_rear.value    

			if (RearVar.length > FormLimit) {
				jiwf.ji_rear.value = RearVar.substr(0, FormLimit)
				RearVar = RearVar.substr(FormLimit)

				while (RearVar.length > 0) {
					var RearTextArea = document.createElement("TEXTAREA")
					RearTextArea.name = "ji_rear"
					RearTextArea.value = RearVar.substr(0, FormLimit)
					jiwf.appendChild(RearTextArea)

					RearVar = RearVar.substr(FormLimit)
				}
			}

			jiwf.action = "Jlogin_info_modify_pro.asp";
			jiwf.method = "post";
			jiwf.target = "";
			jiwf.submit();


		} else {
			alert("������ ��ҵǾ����ϴ�.");
			return;
		}


	}


// MODIFY �� ��




