

// ���� ����


	function allblur() {
		for (i = 0; i < document.links.length; i++)
			document.links[i].onfocus = document.links[i].blur;
	}

	//window.onload = allblur;



	function reset() {
		for (i = 0; i < document.forms.length; i++)
			document.forms[i].value = document.forms[i].reset();
	}



	function onlyNumber() {
		if((event.keyCode<48)||(event.keyCode>57))
		event.returnValue=false;
	}




	function OnClickTR_2() {

		if (document.getElementById("Jsearch_info_write_tr_2").style.display == "none") {
			document.getElementById("Jsearch_info_write_tr_2").style.display = "block";
			document.getElementById("Jsearch_info_write_tr_3").style.display = "block";
			document.getElementById("Jsearch_info_write_tr_4").style.display = "block";
			document.getElementById("Jsearch_info_write_tr_5").style.display = "block";
			document.getElementById("Jsearch_info_write_tr_6").style.display = "none";
			document.getElementById("Jsearch_info_write_tr_7").style.display = "none";
			document.getElementById("Jsearch_info_write_tr_8").style.display = "none";
		}	else {
			document.getElementById("Jsearch_info_write_tr_2").style.display = "none";
			document.getElementById("Jsearch_info_write_tr_3").style.display = "none";
			document.getElementById("Jsearch_info_write_tr_4").style.display = "none";
			document.getElementById("Jsearch_info_write_tr_5").style.display = "none";
		}

	}


	function OnClickTR_3() {

		if (document.getElementById("Jsearch_info_write_tr_6").style.display == "none") {
			document.getElementById("Jsearch_info_write_tr_6").style.display = "block";
			document.getElementById("Jsearch_info_write_tr_7").style.display = "block";
			document.getElementById("Jsearch_info_write_tr_8").style.display = "none";
			document.getElementById("Jsearch_info_write_tr_2").style.display = "none";
			document.getElementById("Jsearch_info_write_tr_3").style.display = "none";
			document.getElementById("Jsearch_info_write_tr_4").style.display = "none";
			document.getElementById("Jsearch_info_write_tr_5").style.display = "none";
		}	else {
			document.getElementById("Jsearch_info_write_tr_6").style.display = "none";
			document.getElementById("Jsearch_info_write_tr_7").style.display = "none";
		}

	}


	function OnClickTR_4() {

		document.getElementById("Jsearch_info_write_tr_2").style.display = "none";
		document.getElementById("Jsearch_info_write_tr_3").style.display = "none";
		document.getElementById("Jsearch_info_write_tr_4").style.display = "none";
		document.getElementById("Jsearch_info_write_tr_5").style.display = "none";
		document.getElementById("Jsearch_info_write_tr_6").style.display = "none";
		document.getElementById("Jsearch_info_write_tr_7").style.display = "none";
		document.getElementById("Jsearch_info_write_tr_8").style.display = "block";
		
	}



	document.getElementById("sub_menu_008").style.display = 'block';
	document.getElementById("sub_course_008").src = '../images/sub_down.gif';
	document.getElementById("sub_vaginal_008").src = '../images/sub_minus.gif';
	document.getElementById("sub_title_008").style.fontWeight='bold';

// ���� ��













// MODIFY �� ����


	function boardSettingCheck() {
		alert('\'�˻���� �Խ���\'�� �������� �ʾҽ��ϴ�.');
	}


	function sendit_2(ji_name) {

		var jiwf = document.Jsearch_info_modify_form;
		var FormLimit = 4000;
		var PrefaceVar = new String;
		var RearVar = new String;
		var select_check;


		if(jiwf.ji_listAu == null) {

			alert("�Խ����� ������� �ʾҽ��ϴ�. \n\n�Խ��ǰ����� �̵��ϼż� �Խ����� �߰��Ͻñ� �ٶ��ϴ�.");
			return;

		} else {

			var len = jiwf.ji_listAu.length;		

			if (len > 0) {

				for(i=0; i < jiwf.ji_listAu.length; i++) {
					if(jiwf.ji_listAu[i].checked) { 
						select_check=jiwf.ji_listAu[i].value; 
						break;
					}
				}

			} else {
				if(jiwf.ji_listAu.checked) { 
					select_check=jiwf.ji_listAu.value;
				}
			}

			if(!select_check) { 
				alert("[�˻���� �Խ���]�� �ϳ��̻� �������ּ���.");
				return;
			}

		}



		if (jiwf.ji_width[0].value == '') {	
			alert("�˻������ ���̸� �Է����ּ���");
			jiwf.ji_width[0].focus();
			return;
		}

		if (jiwf.ji_width[0].value == 0) {	
			alert("�˻������ ���̴� 0���� Ŀ���մϴ�.");
			jiwf.ji_width[0].focus();
			return;
		}

		if (jiwf.ji_insert[2] != undefined)	{
			if (jiwf.ji_insert[2].checked == true && jiwf.ji_AbsFolder.value == '') {	
				alert("���հ˻� ������� ���� ������ ������ �������ּ���.");
				findFolder('Jsearch_info_modify_form','ji_AbsFolder');
				return;
			}
		}


		if (confirm(ji_name+"���������� �����Ͻðڽ��ϱ�?")) {

			PrefaceVar = jiwf.ji_preface.value

			if (PrefaceVar.length > FormLimit) {
				jiwf.ji_preface.value = PrefaceVar.substr(0, FormLimit)
				PrefaceVar = PrefaceVar.substr(FormLimit)

				while (PrefaceVar.length > 0) {
					var PrefaceTextArea = document.createElement("TEXTAREA")
					PrefaceTextArea.name = "ji_preface"
					PrefaceTextArea.value = PrefaceVar.substr(0, FormLimit)
					jiwf.appendChild(PrefaceTextArea)

					PrefaceVar = PrefaceVar.substr(FormLimit)
				}
			}

			
			RearVar = jiwf.ji_rear.value    

			if (RearVar.length > FormLimit) {
				jiwf.ji_rear.value = RearVar.substr(0, FormLimit)
				RearVar = RearVar.substr(FormLimit)

				while (RearVar.length > 0) {
					var RearTextArea = document.createElement("TEXTAREA")
					RearTextArea.name = "ji_rear"
					RearTextArea.value = RearVar.substr(0, FormLimit)
					jiwf.appendChild(RearTextArea)

					RearVar = RearVar.substr(FormLimit)
				}
			}

			jiwf.action = "Jsearch_info_modify_pro.asp";
			jiwf.method = "post";
			jiwf.target = "";
			jiwf.submit();


		} else {
			alert("������ ��ҵǾ����ϴ�.");
			return;
		}


	}



	function sizePrint() {
		document.getElementById("page_len").innerHTML = document.Jsearch_info_modify_form.ji_pagesize.value * 2;
	}



	function source_view() { //Jadmin.js�� completeFindFolder()�� �������� ����ϱ� ����.

	}

// MODIFY �� ��


