

// ���� ����

	if (document.getElementById("sub_menu_0000") != undefined) {
		document.getElementById("sub_menu_0000").style.display = 'block';
		document.getElementById("sub_course_0000").src = '../../adpage/images/sub_down.gif';
		document.getElementById("sub_vaginal_0000").src = '../../adpage/images/sub_minus.gif';
		document.getElementById("sub_title_0000").style.fontWeight='bold';
	}



	var x = 0 
	var y = 0
	drag = 0
	move = 0
	window.document.onmousemove = mouseMove
	window.document.onmousedown = mouseDown 
	window.document.onmouseup = mouseUp 
	window.document.ondragstart = mouseStop 



	function mouseUp() { 
		move = 0 
	}

	function mouseDown() {
		if (drag) {
			clickleft = window.event.x - parseInt(dragObj.style.left) 
			clicktop = window.event.y - parseInt(dragObj.style.top) 
			dragObj.style.zIndex += 1 
			move = 1 
		} 
	} 

	function mouseMove() { 
		if (move) { 
			dragObj.style.left = window.event.x - clickleft 
			dragObj.style.top = window.event.y - clicktop 
		} 
	} 

	function mouseStop() { 
		window.event.returnValue = false 
	}

	function Hide(divid) { 
		divid.style.visibility = "hidden"; 
	} 

	function None(divid) { 
		divid.style.visibility = "hidden"; 
	}


	function Show_remove(divid,folder_name) { 
		var cdf = document.content_delete_form;
		divid.style.top = document.body.scrollTop + 400;
	  divid.style.left = (screen.width - 200) / 2; //200 ���̾��� ����
		divid.style.visibility = "visible";
		cdf.jb_pwd.focus();

		cdf.folder_name.value = folder_name;

		if (cdf.submit.value != undefined) cdf.submit.value = '����';
		cdf.action = '../../Jsource/Jboard/remove_pro.asp';
	}


	
	function Show_secret(divid,ji_num,jb_idx,jb_sort,jb_ref,folder_name) {
		var cdf = document.content_delete_form;
		divid.style.top = document.body.scrollTop + 400;
		divid.style.left = 550;
		divid.style.visibility = "visible";
		cdf.jb_pwd.focus();

		cdf.ji_num.value = ji_num;
		cdf.jb_idx.value = jb_idx;
		cdf.jb_sort.value = jb_sort;
		cdf.jb_ref.value = jb_ref;
		cdf.screen_width.value = screen.width;

		if (cdf.submit.value != undefined) cdf.submit.value = '�Է�';
		cdf.action = "../"+folder_name+"/content.asp";
	}


	function Show_comment(divid, jc_idx, jb_idx) {
		var cdf = document.content_delete_form;
		divid.style.top = document.body.scrollTop + 400;
		divid.style.left = 550;
		divid.style.visibility = "visible";
		cdf.jb_pwd.focus();
		cdf.jc_idx.value = jc_idx;

		if (cdf.submit.value != undefined) cdf.submit.value = '����';
		cdf.action = "../../Jsource/Jboard/comment_remove_pro.asp";
	}



	function No_Space() {  
		if((event.keyCode==32) && document.write_form.jb_title.value.length == 0) {
			event.returnValue=false;
		} else {
			event.returnValue=true; 
		}
	}





	function IsPW(formname) {
		
		var form = eval('document.write_form.'+formname);

		if(form.value.length<4 || form.value.length >13) {
			return false;
		}
		for(var i=0; i<form.value.length; i++) {
			var chr=form.value.substr(i,1);
			if((chr<'0' || chr > '9') && (chr <'0' || chr >'z') && (chr <'0' || chr >'Z')) {
				return false;
			}
		}
		return true;
	}

// ���� ��








// LIST �� ����

	function all_check() {
		
		var jb_idx = document.pagesize_form.jb_idx;

		if (jb_idx == undefined) {
			alert("��ϵ� �Խù��� �����ϴ�.");
			return;
		} else {

			var len = jb_idx.length;

			if (len > 0) {		
				for ( var i=0;i<len; i++ ) {
					if (jb_idx[i].checked)	{
						jb_idx[i].checked = false;
					}	else {
						jb_idx[i].checked = true;
					}	
				}
			} else {
				if (jb_idx.checked)	{
					jb_idx.checked = false;
				}	else {
					jb_idx.checked = true;
				}	
			}

		}

	}



	function check_all(bool) {      
		
		var jb_idx = document.pagesize_form.jb_idx; 

		if (jb_idx == undefined) {
			alert("��ϵ� �Խù��� �����ϴ�.");
			return;
		} else {

			var len = jb_idx.length;

			if (len > 0) {
				if (bool) {          
					for(i=0; i<len; i++) {
						jb_idx[i].checked = true;
					}
					return
				} else {
					for(i=0; i<len; i++) {
						jb_idx[i].checked = false;
					}
					return    
				}
			} else {
				if (bool) {
					jb_idx.checked = true;
					return
				} else {
					jb_idx.checked = false;
					return
				}
			}
		}

	}




	function check_move(ji_num, gotopage, find_sort, find_name, find_title, find_content, find_text, ad_page, folder_name) {

		if (document.pagesize_form.jb_idx == undefined) {
			alert("��ϵ� �Խù��� �����ϴ�.");
			return;
		} else {

			var pf = document.pagesize_form;
			var len = pf.jb_idx.length;
			var submitFlag = 0;

			if (len > 0) {
				for(i=0; i<len; ++i) {
					if(pf.jb_idx[i].name == 'jb_idx') {
						if(pf.jb_idx[i].checked == true) {
							submitFlag = 1;
						break;
						}
					}
				}
			} else {
				if(pf.jb_idx.name == 'jb_idx') {
					if(pf.jb_idx.checked == true) {
						submitFlag = 1;
					}
				}
			}

			if(submitFlag){
				
				var	targetSTR = "../Jboard/pop_JboardInfoList.asp?ji_num="+ji_num+"&gotopage="+gotopage;
				targetSTR +="&find_sort="+find_sort+"&find_name="+find_name;
				targetSTR +="&find_title="+find_title+"&find_content="+find_content;
				targetSTR +="&find_text="+find_text+"&ad_page="+ad_page;
				targetSTR +="&folder_name="+folder_name;
				
				SLB(targetSTR, 'iframe', 400, 250, false, true);
				pf.action = targetSTR;
				pf.target = 'SLB_target';
				pf.method = 'post';
				pf.submit();
				return;

			}	else {
				alert("������ �����ʾҽ��ϴ�."); 
				return;
			}

		}
	}




	function check_remove(ji_num, gotopage, find_sort, find_name, find_title, find_content, find_text, ad_page, folder_name) {

		if (document.pagesize_form.jb_idx == undefined) {
			alert("��ϵ� �Խù��� �����ϴ�.");
			return;
		} else {

			var pf = document.pagesize_form;
			var len = pf.jb_idx.length;
			var submitFlag = 0;

			if (len > 0) {
				for(i=0; i<len; ++i) {
					if(pf.jb_idx[i].name == 'jb_idx') {
						if(pf.jb_idx[i].checked == true) {
							submitFlag = 1;
						break;
						}
					}
				}
			} else {
				if(pf.jb_idx.name == 'jb_idx') {
					if(pf.jb_idx.checked == true) {
						submitFlag = 1;
					}
				}
			}

			if(submitFlag){
				answer1 = confirm("���� �����Ͻðڽ��ϱ�?");
				
				if(answer1 == true) {
					var	targetSTR = "../../Jsource/Jboard/remove_pro.asp?ji_num="+ji_num+"&gotopage="+gotopage;
					targetSTR +="&find_sort="+find_sort+"&find_name="+find_name;
					targetSTR +="&find_title="+find_title+"&find_content="+find_content;
					targetSTR +="&find_text="+find_text+"&ad_page="+ad_page;
					targetSTR +="&folder_name="+folder_name;
					pf.action = targetSTR;
					pf.method = 'post';
					pf.submit();
					return;
				
				} else {
					alert("��ҵǾ����ϴ�.");
					return;
				}

			} else {
				alert("������ �����ʾҽ��ϴ�."); 
				return;
			}
		}

	}





  function search_check() {
		var sf = document.search_form;
		var select_check;

		for(i=0; i < sf.find_sort.length; i++) {
			if(sf.find_sort[i].checked) { 
				select_check=sf.find_sort[i].value; 
				break;
			}
		}

		if(!select_check) { 
			alert("[�˻�����]�� �������ּ���.");
			return false;
		}

		if (sf.find_text.value == "") {
			alert("[�˻���]�� �Է����ּ���.");
			sf.find_text.focus();
			return false;
		}

		sf.action = 'list.asp';
		sf.method = 'post';

  }


  function search_select() {
		var sf = document.search_form;

		if (sf.find_text.value == "") {
			alert("[�˻���]�� �Է����ּ���.");
			sf.find_text.focus();
			return false;
		}

		sf.action = 'list.asp';
		sf.method = 'post';
		
  }



  function search_layer() {
		var sf = document.search_form
	
		if ((sf.find_name.value == "") && (sf.find_title.value == "") && (sf.find_content.value == "")) {
			alert("[�˻�����]�� �������ּ���.");
			return false;
		}
		
		if (sf.find_text.value == "") {
			alert("[�˻���]�� �Է����ּ���.");
			sf.find_text.focus();
			return false;
		}

		sf.action = 'list.asp';
		sf.method = 'post';
		
  }


	
	function FindCheck(name, img_name, img_dir) {
		var str, str_len, str_index, gap
		var sf = document.search_form;
		var field = eval('sf.' + name);
		var img = eval('sf.' + name.replace("find_", ""));


		if (field.value == '0') {
			
			field.value = '';
			
			str = img.value;
			str_len = img.src.length;
			str_index = str.lastIndexOf("\/")+1;	
			gap = str.substring(str_index,str_len);

			img.value = gap;
			img.src = img_dir+ "/"+ gap;

		} else {	
			
			field.value = '0';

			str = img.src;
			str_len = img.src.length;
			str_index = str.lastIndexOf("\/")+1;
			gap = str.substring(str_index,str_len);

			img.value = gap;
			img.src = img_dir+ "/"+ img_name;

		}

	}	






	function JboardMove(ji_name, ji_num, gotopage, find_sort, find_name, find_title, find_content, find_text, ad_page, folder_name, ji_tname, jb_sort) {
		
		var jf = document.JboardInfoList_form;

		if (confirm("������ \'"+ ji_name +"\'�Խ������� �Խù��� �̵��Ͻðڽ��ϱ�?")) {

			var	targetSTR = "../Jboard/pop_JboardInfoList_pro.asp?ji_num="+ji_num+"&gotopage="+gotopage;
			targetSTR +="&find_sort="+find_sort+"&find_name="+find_name;
			targetSTR +="&find_title="+find_title+"&find_content="+find_content;
			targetSTR +="&find_text="+find_text+"&ad_page="+ad_page;
			targetSTR +="&folder_name="+folder_name+"&re_JiTname="+ji_tname;
			targetSTR +="&re_JbSort="+jb_sort;

			jf.action = targetSTR;
			jf.method = 'post';
			jf.submit();

			return;

		}	else {
			alert("�̵��� ��ҵǾ����ϴ�.");
			return;
		}
	}

	


// LIST �� ��







// WRITE �� ����




	
	function OptImgCheck(img_name, img_dir, val) {
		var str, str_len, str_index, img, img_name, gap
		var wf = document.write_form;
		var field = wf.jb_option;
		var CheckChoice = new Array();
		var check, UquareRoot;



		switch(val) {
			case "0": val_name = 'content'
			break;
			case "1": val_name = 'tag'
			break;
			case "2": val_name = 'replymail'
			break;
			case "4": val_name = 'secret'
			break;
			default : val_name = '';
		}



		img = eval('wf.' + val_name);


		if (val > 0) {

			if (field.value == "")	{
				field.value = 0;
			}

			
			for (j=0; j<=2 ;j++)	{

				UquareRoot = Math.pow(2,j);

				CheckChoice[j] = field.value & UquareRoot;
				if (CheckChoice[j] == val)	{
					check = "ok";
				}
			}

			if (check == "ok") {

				field.value = parseFloat(field.value) - parseFloat(val);
				
				str = img.value;
				str_len = img.src.length;
				str_index = str.lastIndexOf("\/")+1;	
				gap = str.substring(str_index,str_len);

				img.value = gap;
				img.src = img_dir+ "/"+ gap;

			} else {	
				
				field.value = parseFloat(field.value) + parseFloat(val);

				str = img.src;
				str_len = img.src.length;
				str_index = str.lastIndexOf("\/")+1;
				gap = str.substring(str_index,str_len);

				img.value = gap;
				img.src = img_dir+ "/"+ img_name;

			}

		} else if (val == 0) {

			if (img.value == img_name) {
				img.value = 'check_off.gif';
				img.src = img_dir+ "/check_off.gif";
			} else {
				img.value = img_name;
				img.src = img_dir+ "/"+ img_name;
			}

		}

	}	



	
	function OptBoxCheck(val) {
		var wf = document.write_form;
		var field = wf.jb_option;
		var CheckChoice = new Array();
		var check, UquareRoot;

		if (field.value == "")	{
			field.value = 0;
		}

		for (j=0; j<=2 ;j++)	{

			UquareRoot = Math.pow(2,j);

			CheckChoice[j] = field.value & UquareRoot;
			if (CheckChoice[j] == val)	{
				check = "ok";
			}
		}

		if (check == "ok") {
			field.value = parseFloat(field.value) - parseFloat(val);
		} else {
			field.value = parseFloat(field.value) + parseFloat(val);		
		}

			
	}	



	
	function NotImgCheck(img_name, img_dir) {
		var str, str_len, str_index
		var wf = document.write_form;
		var field = wf.jb_notice;
		var img = wf.notice;


		if (field.value == '1') {
			
			field.value = '';
			
			str = img.value;
			str_len = img.src.length;
			str_index = str.lastIndexOf("\/")+1;	
			gap = str.substring(str_index,str_len);

			img.value = gap;
			img.src = img_dir+ "/"+ gap;

		} else {	
			
			field.value = '1';

			str = img.src;
			str_len = img.src.length;
			str_index = str.lastIndexOf("\/")+1;
			gap = str.substring(str_index,str_len);

			img.value = gap;
			img.src = img_dir+ "/"+ img_name;

		}

	}	


	function NotBoxCheck(val) {
		var wf = document.write_form;
		var field = wf.jb_notice;

		if (field.value == "")	{
			field.value = 0;
		}

		if (field.value == '1') {
			field.value = '';		
		} else {
			field.value = '1';
		}
			
	}	





	function ShowProcess(divid) {

		var winl = (screen.width - 214) / 2;
		var wint = (screen.height - 250) / 2;

		divid.style.visibility = "visible";
		divid.style.top = wint;
		divid.style.left = winl;
	
	} 



	var Trans = false;
	function registContent(ji_upload, ji_upnum, ji_num, mode, ad_page, folder_name, PwdInput_View, ji_listChoice, ji_writeChoice, ji_highChoice) {
 
		var regExt =/(\.[^\.]*$)/;
		var submitFlag = 0;
		var wf = document.write_form;
	
		var varSTR = "ji_num="+ji_num+"&ad_page="+ad_page+"&folder_name="+folder_name+"&screen_width="+screen.width+"&mode="+mode;

		var ListChoice = new Array();
		var WriteChoice = new Array();
		var HighChoice = new Array();
		var UquareRoot;

		for (j=0; j<=15 ;j++)	{

			UquareRoot = Math.pow(2,j);

			ListChoice[j] = ji_listChoice & UquareRoot;

		}

		for (j=0; j<=9 ;j++)	{

			UquareRoot = Math.pow(2,j);

			WriteChoice[j] = ji_writeChoice & UquareRoot;

		}

		for (j=0; j<=3 ;j++)	{

			UquareRoot = Math.pow(2,j);

			HighChoice[j] = ji_highChoice & UquareRoot;

		}


		if (wf.jb_sort != undefined) {
			
			if (wf.jb_sort.value == "") {
				 alert("[ī�װ���]�� �����ϼ���.");
				 wf.jb_sort.focus();
				 return;
			}

			var jb_sort = wf.jb_sort.value;
			varSTR = varSTR +"&jb_sort="+jb_sort;
		}
		
		if (wf.jb_name.value == "") {
			 alert("[�̸�]�� �Է����ּ���.");
			 wf.jb_name.focus();
			 return;
		}

		if (PwdInput_View == 'ok')	{
			if (wf.jb_pwd.value == "" ) {
				 alert("[��й�ȣ]�� �Է����ּ���.");
				 wf.jb_pwd.focus();
				 return;
			}
			if (!IsPW(write_form.jb_pwd.name)) { 
				 alert('[��й�ȣ]�� 4~12���� ���� �Ǵ� ���ڷ� ���յ� ���ڿ��̾�� �մϴ�.'); 
				 wf.jb_pwd.focus();
				 return;
			}
		}

		if (WriteChoice[4] > 0)	{

			if (wf.jb_email.value!="") {
				var tempchar = 0;
				for (i=0;i<wf.jb_email.value.length; i++ ) {
						 temp = wf.jb_email.value.charAt(i);
					if (temp == "@" || temp ==".") {
						tempchar++; 
					}
				}
				if (tempchar < 2) {
					alert("�̸����� �߸��Է��ϼ̽��ϴ�.");
					wf.jb_email.focus();
					return;
				}
			}
		}
		
		if (wf.jb_title.value == "") {
			 alert("[����]�� �Է����ּ���.");
			 wf.jb_title.focus();
			 return;
		}


		/*
		if (wf.jb_etc != undefined) {

			var sf = document.hiddenMain.select_form;	
			if (sf.fa_code.value == "") {
				 alert("[]�� ??�� �������ּ���.");
				 sf.fa_code.focus();
				 return;
			}

			wf.jb_etc.value = sf.fa_code.value+ ", " +sf.pr_kind.value;

		}
		*/


		if (HighChoice[0] > 0)	{

			if (myeditor.outputBodyHTML() == '') {
				 alert("[����]�� �Է����ּ���.");
				 myeditor.editArea.focus();
				 return;
			}	

		} else {
		
			if (wf.jb_content.value == "") {
				 alert("[����]�� �Է����ּ���.");
				 wf.jb_content.focus();
				 return;
			}			
		
		}


		if (ji_upnum > 0) {

			for (j=1 ; j<=ji_upnum ; j++) {
				frm = eval('wf.'+mode+'_file_' + j)
				fileStr = frm.value;
						
				filename = fileStr.replace(regExt, "");
						
			  strExt = fileStr.replace(filename,"").toLowerCase();
						
				if (strExt == ".asp" || strExt == ".aspx" || strExt == ".exe" || strExt == ".htr" || strExt == ".cer" || strExt == ".asa") {
					alert("�����Ͻ� ������ ���ε� �Ͻ� �� �����ϴ�.");								 
					frm.focus();
					return;
				}

			}

		}
	

		if (ListChoice[14] > 0) {

			for (j=1 ; j<=1 ; j++) {
				
				if (mode == 'modify' ) {
					frm = eval('wf.shell_' + j);
				} else {
					frm = eval('wf.'+mode+'_file_' + j);
				}

				fileStr = frm.value;

				if (fileStr != "") {
						
					filename = fileStr.replace(regExt, "");
							
					strExt = fileStr.replace(filename,"").toLowerCase();
							
					if (strExt != ".gif" && strExt != ".jpg" && strExt != ".jpeg") {
						alert("������ ���� ù��° ������ Ȯ���� gif, jpg, jpeg �ܿ��� ���ε带 ���մϴ�.");								 
						frm.focus();
						return;
					}	
					submitFlag = 1;
				}
			}

			if (submitFlag == 0) {
				alert("ù��° �̹����� ����ϼž� �˴ϴ�.");
				return;
			}

		}

		if (WriteChoice[2] > 0)	{

			var CheckChoice = new Array();
			var check;

			for (j=0; j<=2 ;j++)	{

				UquareRoot = Math.pow(2,j);

				CheckChoice[j] = wf.jb_option.value & UquareRoot;
				if (CheckChoice[j] == 2 && wf.jb_email.value == "")	{
					alert("�亯���Ϲޱ⸦ �����ϼ̴ٸ� \n\n[�̸���]�� �Է����ּ��� ");
					wf.jb_email.focus();
					return;
					break;
				}
			}
			
		}


		if (wf.cl_class != undefined) {

			if (mode == 'reply' && WriteChoice[3] > 0)	{

				var CheckChoice = new Array();
				var check;

				
				for (j=0; j<=2 ;j++)	{

					UquareRoot = Math.pow(2,j);

					CheckChoice[j] = wf.jb_option.value & UquareRoot;
					if (CheckChoice[j] == 4 && wf.cl_class.value <= 2 && wf.me_id.value == '')	{
						wf.jb_pwd.disabled=false;
						break;				
					} else {
						wf.jb_pwd.disabled=true;
					}
				}
			}
				
		}


		if (HighChoice[0] > 0)	{

			var data = myeditor.getImages();
			var comma = ", ";

			if (data != null) {
				for (var i = 0; i < data.length; i++) {
					
					if (i > 0 )	{
						wf.editorImage.value += comma + data[i].fileName;
					} else {
						wf.editorImage.value = data[i].fileName;
					}
					
				}
			}
			wf.fm_write.value = myeditor.outputBodyHTML();

		}



		if (ji_upnum > 0 && wf.jb_etc != undefined) { //DEXT .count������Ƽ ���� �ش��Ķ���Ͱ� �� ����ÿ��� 1�� ó��
			wf.arr_etc.value = document.getElementsByName("jb_etc").length;
		} else {
			wf.arr_etc.value = 0;
		}

		if (ji_upnum > 0) {
			wf.action = "../../Jsource/Jboard/"+mode+"_pro_"+ji_upload+"_pds.asp?"+varSTR;
		} else {
			wf.action = "../../Jsource/Jboard/"+mode+"_pro_bbs.asp?"+varSTR;
		}

		if (Trans == false) {
			
			ShowProcess(JboardProcess);

			wf.method = "post";
			//wf.target = "ProcessFm";
			wf.submit();
		}

		Trans = true;

  }



	function CheckBox_content(HighChoice0) {
		var rf = document.write_form;

		if (HighChoice0 > 0) {
			var field = eval('rf.fm_write');
			
			if(field.value!='') {
				field.value = '';
				myeditor.doc.body.innerText = '';
			} else {
				field.value = '0';
				myeditor.doc.body.innerText = rf.jb_content_save.value;								
			}		
		} else {
			var field = eval('rf.jb_content');	

			if(field.value!='') {
				field.value = '';
			} else {
				field.value = '0';
				rf.jb_content.value = rf.jb_content_save.value;				
			}		
		}

	}	



	function write_admin(ji_upload, ji_upnum, ji_num, mode, ad_page, folder_name, PwdInput_View, ji_listChoice, ji_writeChoice, ji_highChoice) {

		if (mode == 'write') ment = "���"

		if (mode == 'modify') ment = "����"

		if (mode == 'reply') ment = "���(�亯)"

		if (confirm("�Խù��� "+ment+"�Ͻðڽ��ϱ�?")) {

			registContent(ji_upload, ji_upnum, ji_num, mode, ad_page, folder_name, PwdInput_View, ji_listChoice, ji_writeChoice, ji_highChoice) ;
			
		} else {
			alert(ment+"�� ��ҵǾ����ϴ�.");
		}
	}




	function write_member(ji_upload, ji_upnum, ji_num, mode, ad_page, folder_name, PwdInput_View, ji_listChoice, ji_writeChoice, ji_highChoice) {

		if (mode == 'write') ment = "���"

		if (mode == 'modify') ment = "����"

		if (mode == 'reply') ment = "���(�亯)"

		if (confirm("�Խù��� "+ment+"�Ͻðڽ��ϱ�?")) {

			registContent(ji_upload, ji_upnum, ji_num, mode, ad_page, folder_name, PwdInput_View, ji_listChoice, ji_writeChoice, ji_highChoice) ;
			
		} else {
			alert(ment+"�� ��ҵǾ����ϴ�.");
		}
	}



	function fileShellreg(form_name, file_num, mode) {
	
		var frm = eval('document.'+form_name);
		var shellFile = eval('frm.shell_'+file_num)
		var realFile = eval('frm.'+mode+'_file_'+file_num);

		shellFile.value = realFile.value;

    var shellFileStr = shellFile.value;
    var shellFileStr_len = shellFile.value.length;
    var shellFileStr_index = shellFileStr.lastIndexOf("\\")+1;
    
    shellFileName = shellFileStr.substring(shellFileStr_index,shellFileStr_len);
    shellFile.value = shellFileName;

	}


// WRITE �� ��













// CONTENT �� ����

	function remove_submit(mode) {

		var cd = document.content_delete_form;

		if (cd.jb_pwd.value == "") {
			alert("�н����带 �Է��ϼ���.");
			cd.jb_pwd.focus();
			return false;
		}

		if (mode == 'secret')	cd.action = "../"+cd.folder_name.value+"/content.asp";
		if (mode == 'remove')	cd.action = '../../Jsource/Jboard/remove_pro.asp';
		if (mode == 'CommentRemove')	cd.action = '../../Jsource/Jboard/comment_remove_pro.asp';

	}





	var Trans = false;
	function add_boardComment(me_id, ji_highChoice) {

		 
		var cf = document.comm_form;
		var HighChoice = new Array();
		var UquareRoot;

		
		for (j=0; j<=3 ;j++)	{

			UquareRoot = Math.pow(2,j);

			HighChoice[j] = ji_highChoice & UquareRoot;

		}


		if (cf.jc_name.value == "") {
			alert("�̸��� �Է����ּ���.");
			cf.jc_name.focus();
			return;
		}

		if (me_id == '')	{
			if (cf.jc_pwd.value == "") {
				alert("�н����带 �Է����ּ���.");
				cf.jc_pwd.focus();
				return;
			}
		}


		if (cf.jc_content.value == "") {
			 alert("�ǰ߱��� �Է����ּ���.");
			 cf.jc_content.focus();
			 return;
		}			
		
		if (Trans == false) {

			cf.action = "../../Jsource/Jboard/comment_write_pro.asp";
			cf.method = "post";
			cf.submit();
		}

		Trans = true;
	}





	function MM_findObj(n, d) { //v4.01
		var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
			d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
		if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
		for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
		if(!x && d.getElementById) x=d.getElementById(n); return x;
	}

	function MM_swapImage() { //v3.0
		var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
		 if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
	}



	function show_POP(ji_num, jb_idx, ji_tname, jb_sort, img_name, jf_idx, useUTF) { 

		var imgObj = new Image(); 
		imgObj.src = "../../data/"+ji_tname+"/"+jb_sort+"/"+img_name; 

		var img_w = imgObj.width;
		var img_h = imgObj.height;
		var screen_width = screen.width;
		var screen_height = screen.height;
		var winw, winh, Vimg_w, Vimg_h;


		if (img_w > (screen_width-256))  {
			Vimg_w = (screen_width-239);
			winw	 = parseInt((screen_width - Vimg_w - 17) / 2);
		} else {
			Vimg_w = parseInt(img_w+17);
			winw	 = parseInt((screen_width - Vimg_w) / 2);
		}

		if (img_h > (screen_height-256)) {
			Vimg_h = parseInt(img_h * (Vimg_w/img_w));
			if (Vimg_h > (screen_height-256))	Vimg_h = (screen_height-256);
			winh	 = parseInt((screen_height - Vimg_h - 40) / 2)-20;
		} else {
			Vimg_h = parseInt(img_h);
			winh	 = parseInt((screen_height - Vimg_h) / 2)-20;
		}
		

		var opt = 'toolbar=no,resizable=yes,scrollbars=yes,location=no,resize=no,menubar=no,';
		opt=opt+'status=yes,directories=no,copyhistory=0,';
		opt=opt+'width='+Vimg_w+',height='+Vimg_h+',top='+winh+',left='+winw; 


		var targetSTR = "../../Jsource/Jboard/include/img_pop.asp?ji_num="+ji_num+"&jb_idx="+jb_idx;
		targetSTR +="&jb_sort="+jb_sort+"&jf_idx="+jf_idx;
		targetSTR +="&img_width="+img_w+"&img_height="+img_h;
		targetSTR +="&screen_width="+screen_width;
		if (useUTF != '')	{
			targetSTR +='&jb_file='+encodeURL(img_name);
		} else {
			targetSTR +='&jb_file='+img_name;
		}
		window.open(targetSTR, 'jsSize', opt);

	} 




	function show_subNext(ji_num, jb_idx, ji_tname, jb_sort, img_name, jf_idx, useUTF) { 

		var imgObj = new Image(); 
		if (useUTF != '')	{
			imgObj.src = "../../data/"+ji_tname+"/"+jb_sort+"/"+encodeURL(img_name);
		} else {
			imgObj.src = "../../data/"+ji_tname+"/"+jb_sort+"/"+img_name; 
		}
		
		var img_w = imgObj.width;
		var img_h = imgObj.height;
		var screen_width = screen.width;
		var screen_height = screen.height;
		var winw, winh, Vimg_w, Vimg_h;


		if (img_w > (screen_width-256))  {
			Vimg_w = (screen_width-239);
			winw	 = parseInt((screen_width - Vimg_w - 17) / 2);
		} else {
			Vimg_w = parseInt(img_w+17);
			winw	 = parseInt((screen_width - Vimg_w) / 2);
		}

		if (img_h > (screen_height-256)) {
			Vimg_h = parseInt(img_h * (Vimg_w/img_w));
			if (Vimg_h > (screen_height-256))	Vimg_h = (screen_height-256);
			winh	 = parseInt((screen_height - Vimg_h - 40) / 2)-20;
		} else {
			Vimg_h = parseInt(img_h);
			winh	 = parseInt((screen_height - Vimg_h) / 2)-20;
		}


		var opt = 'toolbar=no,resizable=yes,scrollbars=yes,location=no,resize=no,menubar=no,';
		opt=opt+'status=yes,directories=no,copyhistory=0,';
		opt=opt+'width='+Vimg_w+',height='+Vimg_h+',top='+winh+',left='+winw; 


		var targetSTR = "../../Jsource/Jboard/include/img_subNext.asp?ji_num="+ji_num+"&jb_idx="+jb_idx;
		targetSTR +="&jb_sort="+jb_sort;
		targetSTR +="&img_width="+img_w+"&img_height="+img_h;
		targetSTR +="&screen_width="+screen_width;
		window.open(targetSTR, 'subNext', opt);

	} 




	function show_reSize(ji_num, jb_idx, ji_tname, jb_sort, img_name, find_sort, find_name, find_title, find_content, find_text, s_idx, e_idx, reSizeRemain, useUTF) { 

		var imgObj = new Image(); 
		if (useUTF != '')	{
			imgObj.src = "../../data/"+ji_tname+"/"+jb_sort+"/"+encodeURL(img_name);
		} else {
			imgObj.src = "../../data/"+ji_tname+"/"+jb_sort+"/"+img_name; 
		}

		var img_w = imgObj.width;
		var img_h = imgObj.height;
		var screen_width = screen.width;
		var screen_height = screen.height;
		var winw, winh, Vimg_w, Vimg_h;


		if (img_w > (screen_width-256))  {
			Vimg_w = (screen_width-239);
			winw	 = parseInt((screen_width - Vimg_w - 17) / 2);
		} else {
			Vimg_w = parseInt(img_w+17);
			winw	 = parseInt((screen_width - Vimg_w) / 2);
		}

		if (img_h > (screen_height-256)) {
			Vimg_h = parseInt(img_h * (Vimg_w/img_w));
			if (Vimg_h > (screen_height-256))	Vimg_h = (screen_height-256);
			winh	 = parseInt((screen_height - Vimg_h - 40) / 2)-20;
		} else {
			Vimg_h = parseInt(img_h);
			winh	 = parseInt((screen_height - Vimg_h) / 2)-20;
		}


		var opt = 'toolbar=no,resizable=yes,scrollbars=yes,location=no,resize=no,menubar=no,';
		opt=opt+'status=yes,directories=no,copyhistory=0,';
		opt=opt+'width='+Vimg_w+',height='+Vimg_h+',top='+winh+',left='+winw; 


		var targetSTR = "../../Jsource/Jboard/include/img_reSize.asp?ji_num="+ji_num+"&jb_idx="+jb_idx+"&jb_sort="+jb_sort;
		targetSTR +="&find_sort="+find_sort+"&find_name="+find_name;
		targetSTR +="&find_title="+find_title+"&find_content="+find_content;
		targetSTR +="&find_text="+find_text;
		targetSTR +="&s_idx="+s_idx+"&e_idx="+e_idx+"&reSizeRemain="+reSizeRemain;
		targetSTR +="&img_width="+img_w+"&img_height="+img_h;
		targetSTR +="&screen_width="+screen_width;
		window.open(targetSTR, 'ShowReSize', opt);

	}






	function file_down(ji_num, jb_idx, jb_sort, jf_idx) {

		var targetSTR;
		targetSTR = '../../Jsource/Jboard/include/download.asp?ji_num='+ji_num+'&jb_idx='+jb_idx;
		targetSTR +='&jb_sort='+jb_sort+'&jf_idx='+jf_idx;
		window.location.href = targetSTR;

	}




	function PassInput_view(ji_num, jb_idx, rs2jb_sort, jb_ref, gotopage, find_sort, find_name, find_title, find_content, find_text, ad_page) {
		var targetSTR;

		targetSTR = "remove.asp?ji_num="+ji_num+"&jb_idx="+jb_idx+"&jb_sort="+rs2jb_sort+"&jb_ref="+jb_ref+"&gotopage="+gotopage;
		targetSTR +="&find_sort="+find_sort+"&find_name="+find_name;
		targetSTR +="&find_title="+find_title+"&find_content="+find_content;
		targetSTR +="&find_text="+find_text+"&ad_page="+ad_page;
		targetSTR +="&screen_width="+screen.width+"&mode=secret";
		window.location.href = targetSTR;
	}




	function common_CategorySelect(obj, ji_num, ad_page, ji_caNum) {
		var clf = document.commonLinkForm;
		var var_sort = obj.value;
		var sort_len = var_sort.length; //ji_num�� ���̸� ����

		ji_num = var_sort.substring(6,sort_len);
		jb_sort = var_sort.substring(0,5);

		if(jb_sort == "") {
			ji_num = ji_caNum;
			jb_sort = '';
		}

		clf.jb_sort.value = jb_sort;
		clf.ad_page.value = ad_page;

		clf.action = 'list.asp?ji_num='+ji_num;
		clf.method = 'post';
		clf.submit();
	}


	function commonLink(folder_name, page_name, gotopage, ji_num, jb_sort, jb_idx, jb_ref, find_sort, find_name, find_title, find_content, find_text, ad_page, mode) {


		var clf = document.commonLinkForm;
		var target = 'JboardFrame';
		parent.name = target;

		clf.folder_name.value = folder_name;
		clf.page_name.value = page_name;
		clf.gotopage.value = gotopage;
		clf.jb_ref.value = jb_ref;
		clf.find_sort.value = find_sort;
		clf.find_name.value = find_name;
		clf.find_title.value = find_title;
		clf.find_content.value = find_content;
		clf.find_text.value = find_text;
		clf.ad_page.value = ad_page;
		clf.mode.value = mode;
		clf.screen_width.value = screen.width;

		clf.jc_idx.value = jb_ref; //�ڸ�Ʈ���� ���

		if (page_name == 'content.asp') {
			page_name = page_name +"?ji_num="+ji_num+"&jb_sort="+jb_sort+"&jb_idx="+jb_idx
		} else {
			page_name = page_name +"?ji_num="+ji_num
			clf.jb_sort.value = jb_sort;
			clf.jb_idx.value = jb_idx;
		}


		if (mode == 'print') {
			clf.target = '_blank';
		}	else {
			clf.target = target;
		}

		clf.action = page_name;
		clf.method = 'post';

		if (mode == 'removeOK') {
			if (confirm("���� �Խù��� �����Ͻðڽ��ϱ�?")) {
				clf.submit();
			} else {
				alert("������ ��ҵǾ����ϴ�.");
			}
		} else if (mode == 'commentRemoveOK') {
			if (confirm("���� �ǰ߱��� �����Ͻðڽ��ϱ�?")) {
				clf.submit();
			} else {
				alert("������ ��ҵǾ����ϴ�.");
			}
		} else {
			clf.submit();
		}
	}




	var xmlhttp = null; 
	if(window.XMLHttpRequest) { // FF�� ��� window.XMLHttpRequest ��ü����
		xmlRequest = new XMLHttpRequest(); // FF ��ü���� 
	} else { 
		xmlRequest = new ActiveXObject("Microsoft.XMLHTTP"); // IE ��ü���� 
	} 


	function ajaxCommentView(no, jc_idx, mode) {

		var cf = document.comm_form;
		var ji_num = cf.ji_num.value;
		var jb_idx = cf.jb_idx.value;
		var jb_sort = cf.jb_sort.value;
		var gotopage = cf.gotopage.value;
		var ad_page = cf.ad_page.value;
		var folder_name = cf.folder_name.value;
		

		if (cf.commentViewCount.value == no && cf.nowState.value == mode && document.getElementById("commentTextView"+no).innerHTML != '') {
			var viewForm = '';
			document.getElementById("commentTextView"+no).innerHTML = ''
		} else {
			var viewForm = 'ok';
		}

		cf.commentViewCount.value = no;
		cf.nowState.value = mode;
		

		if (viewForm == 'ok')	{
			var url = "../../Jsource/Jboard/ajax_comment.asp?ji_num="+ji_num;
			url +="&jb_idx="+jb_idx+"&jb_sort="+jb_sort+"&jc_idx="+jc_idx;
			url +="&gotopage="+gotopage+"&ad_page="+escape(ad_page)+"&folder_name="+escape(folder_name)+"&mode="+escape(mode);
			xmlRequest.open("GET",url,true);
			xmlRequest.onreadystatechange = commentInputView;
			xmlRequest.send(null);
		}

	}




	function commentInputView() {
				
		var cf = document.comm_form;
		var CommentCount = cf.CommentCount.value;
		var commentViewCount = cf.commentViewCount.value;
		var nowState = cf.nowState.value;

		if (xmlRequest.readyState == 4){

			var commentTextView = xmlRequest.responseText;

				if (document.getElementById("commentTextView"+commentViewCount).innerHTML == '')	{

					for (i = 0; i <= CommentCount-1; i++) {
						document.getElementById("commentTextView"+i).innerHTML = '';
					}

					document.getElementById("commentTextView"+commentViewCount).innerHTML = commentTextView;	

				} else if (document.getElementById("commentTextView"+commentViewCount).innerHTML != '')	{

					document.getElementById("commentTextView"+commentViewCount).innerHTML = commentTextView;	

				}
				
			}

	}


	function commentInputClose() {
				
		var cf = document.comm_form;
		var commentViewCount = cf.commentViewCount.value;

		document.getElementById("commentTextView"+commentViewCount).innerHTML = '';	

	}




	var Trans = false;
	function commentExec(me_id, ji_highChoice, mode) {

		 
		var rf = document.reply_form;
		var HighChoice = new Array();
		var UquareRoot;

		
		for (j=0; j<=3 ;j++)	{

			UquareRoot = Math.pow(2,j);

			HighChoice[j] = ji_highChoice & UquareRoot;

		}


		if (rf.jc_name.value == "") {
			alert("�̸��� �Է����ּ���.");
			rf.jc_name.focus();
			return;
		}

		if (rf.jc_pwd != null)	{
			if (rf.jc_pwd.value == "") {
				alert("�н����带 �Է����ּ���.");
				rf.jc_pwd.focus();
				return;
			}
		}


		if (rf.jc_content.value == "") {
			 alert("�ǰ߱��� �Է����ּ���.");
			 rf.jc_content.focus();
			 return;
		}			
		

		rf.action = "../../Jsource/Jboard/comment_"+mode+"_pro.asp";
		rf.method = "post";

		if (mode == 'modify' && rf.jc_pwd == null) {
			if (confirm("�ǰ߱��� �����Ͻðڽ��ϱ�?"))	{
				if (Trans == false) rf.submit();
			} else {
				alert('��ҵǾ����ϴ�.');			
			}
		} else {
			if (Trans == false) rf.submit();		
		}

		Trans = true;
	}




// CONTENT �� ��



