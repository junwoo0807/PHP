/* --- BoxOver ---
/* --- v 2.1 17th June 2006
By Oliver Bryant with help of Matthew Tagg
http://boxover.swazz.org */

if (typeof document.attachEvent!='undefined') {
   window.attachEvent('onload',init);
   document.attachEvent('onmousemove',moveMouse);
   document.attachEvent('onclick',checkMove); }
else {
   window.addEventListener('load',init,false);
   document.addEventListener('mousemove',moveMouse,false);
   document.addEventListener('click',checkMove,false);
}

var oDv=document.createElement("div");
var dvHdr=document.createElement("div");
var dvBdy=document.createElement("div");
var windowlock,boxMove,fixposx,fixposy,lockX,lockY,fixx,fixy,ox,oy,boxLeft,boxRight,boxTop,boxBottom,evt,mouseX,mouseY,boxOpen,totalScrollTop,totalScrollLeft;
boxOpen=false;
ox=10;
oy=10;
lockX=0;
lockY=0;

function init() {
	oDv.appendChild(dvHdr);
	oDv.appendChild(dvBdy);
	oDv.style.position="absolute";
	oDv.style.visibility='hidden';
	document.body.appendChild(oDv);	
}

function defHdrStyle() {
	dvHdr.innerHTML='<img  style="vertical-align:middle"  src="info.gif">&nbsp;&nbsp;'+dvHdr.innerHTML;
	dvHdr.style.fontWeight='bold';
	dvHdr.style.width='150px';
	dvHdr.style.fontFamily='arial';
	dvHdr.style.border='1px solid #A5CFE9';
	dvHdr.style.padding='3';
	dvHdr.style.fontSize='11';
	dvHdr.style.color='#4B7A98';
	dvHdr.style.background='#D5EBF9';
	dvHdr.style.filter='alpha(opacity=85)'; // IE
	dvHdr.style.opacity='0.85'; // FF
}

function defBdyStyle() {
	dvBdy.style.borderBottom='1px solid #A5CFE9';
	dvBdy.style.borderLeft='1px solid #A5CFE9';
	dvBdy.style.borderRight='1px solid #A5CFE9';
	dvBdy.style.width='150px';
	dvBdy.style.fontFamily='arial';
	dvBdy.style.fontSize='11';
	dvBdy.style.padding='3';
	dvBdy.style.color='#1B4966';
	dvBdy.style.background='#FFFFFF';
	dvBdy.style.filter='alpha(opacity=85)'; // IE
	dvBdy.style.opacity='0.85'; // FF
}

function checkElemBO(txt) {
if (!txt || typeof(txt) != 'string') return false;
if ((txt.indexOf('header')>-1)&&(txt.indexOf('body')>-1)&&(txt.indexOf('[')>-1)&&(txt.indexOf('[')>-1)) 
   return true;
else
   return false;
}

function scanBO(curNode) {
	  if (checkElemBO(curNode.title)) {
         curNode.boHDR=getParam('header',curNode.title);
         curNode.boBDY=getParam('body',curNode.title);
			curNode.boCSSBDY=getParam('cssbody',curNode.title);			
			curNode.boCSSHDR=getParam('cssheader',curNode.title);
			curNode.IEbugfix=(getParam('hideselects',curNode.title)=='on')?true:false;
			curNode.fixX=parseInt(getParam('fixedrelx',curNode.title));
			curNode.fixY=parseInt(getParam('fixedrely',curNode.title));
			curNode.absX=parseInt(getParam('fixedabsx',curNode.title));
			curNode.absY=parseInt(getParam('fixedabsy',curNode.title));
			curNode.offY=(getParam('offsety',curNode.title)!='')?parseInt(getParam('offsety',curNode.title)):10;
			curNode.offX=(getParam('offsetx',curNode.title)!='')?parseInt(getParam('offsetx',curNode.title)):10;
			curNode.fade=(getParam('fade',curNode.title)=='on')?true:false;
			curNode.fadespeed=(getParam('fadespeed',curNode.title)!='')?getParam('fadespeed',curNode.title):0.04;
			curNode.delay=(getParam('delay',curNode.title)!='')?parseInt(getParam('delay',curNode.title)):0;
			if (getParam('requireclick',curNode.title)=='on') {
				curNode.requireclick=true;
				document.all?curNode.attachEvent('onclick',showHideBox):curNode.addEventListener('click',showHideBox,false);
				document.all?curNode.attachEvent('onmouseover',hideBox):curNode.addEventListener('mouseover',hideBox,false);
			}
			else {// Note : if requireclick is on the stop clicks are ignored   			
   			if (getParam('doubleclickstop',curNode.title)!='off') {
   				document.all?curNode.attachEvent('ondblclick',pauseBox):curNode.addEventListener('dblclick',pauseBox,false);
   			}	
   			if (getParam('singleclickstop',curNode.title)=='on') {
   				document.all?curNode.attachEvent('onclick',pauseBox):curNode.addEventListener('click',pauseBox,false);
   			}
   		}
			curNode.windowLock=getParam('windowlock',curNode.title).toLowerCase()=='off'?false:true;
			curNode.title='';
			curNode.hasbox=1;
	   }
	   else
	      curNode.hasbox=2;   
}


function getParam(param,list) {
	var reg = new RegExp('([^a-zA-Z]' + param + '|^' + param + ')\\s*=\\s*\\[\\s*(((\\[\\[)|(\\]\\])|([^\\]\\[]))*)\\s*\\]');
	var res = reg.exec(list);
	var returnvar;
	if(res)
		return res[2].replace('[[','[').replace(']]',']');
	else
		return '';
}

function Left(elem){	
	var x=0;
	if (elem.calcLeft)
		return elem.calcLeft;
	var oElem=elem;
	while(elem){
		 if ((elem.currentStyle)&& (!isNaN(parseInt(elem.currentStyle.borderLeftWidth)))&&(x!=0))
		 	x+=parseInt(elem.currentStyle.borderLeftWidth);
		 x+=elem.offsetLeft;
		 elem=elem.offsetParent;
	  } 
	oElem.calcLeft=x;
	return x;
	}

function Top(elem){
	 var x=0;
	 if (elem.calcTop)
	 	return elem.calcTop;
	 var oElem=elem;
	 while(elem){		
	 	 if ((elem.currentStyle)&& (!isNaN(parseInt(elem.currentStyle.borderTopWidth)))&&(x!=0))
		 	x+=parseInt(elem.currentStyle.borderTopWidth); 
		 x+=elem.offsetTop;
	         elem=elem.offsetParent;
 	 } 
 	 oElem.calcTop=x;
 	 return x;
 	 
}

var ah,ab;
function applyStyles() {
	if(ab)
		oDv.removeChild(dvBdy);
	if (ah)
		oDv.removeChild(dvHdr);
	dvHdr=document.createElement("div");
	dvBdy=document.createElement("div");
	CBE.boCSSBDY?dvBdy.className=CBE.boCSSBDY:defBdyStyle();
	CBE.boCSSHDR?dvHdr.className=CBE.boCSSHDR:defHdrStyle();
	dvHdr.innerHTML=CBE.boHDR;
	dvBdy.innerHTML=CBE.boBDY;
	ah=false;
	ab=false;
	if (CBE.boHDR!='') {		
		oDv.appendChild(dvHdr);
		ah=true;
	}	
	if (CBE.boBDY!=''){
		oDv.appendChild(dvBdy);
		ab=true;
	}	
}

var CSE,iterElem,LSE,CBE,LBE, totalScrollLeft, totalScrollTop, width, height ;
var ini=false;

// Customised function for inner window dimension
function SHW() {
   if (document.body && (document.body.clientWidth !=0)) {
      width=document.body.clientWidth;
      height=document.body.clientHeight;
   }
   if (document.documentElement && (document.documentElement.clientWidth!=0) && (document.body.clientWidth + 20 >= document.documentElement.clientWidth)) {
      width=document.documentElement.clientWidth;   
      height=document.documentElement.clientHeight;   
   }   
   return [width,height];
}


var ID=null;
function moveMouse(e) {
   //boxMove=true;
	e?evt=e:evt=event;
	
	CSE=evt.target?evt.target:evt.srcElement;
	
	if (!CSE.hasbox) {
	   // Note we need to scan up DOM here, some elements like TR don't get triggered as srcElement
	   iElem=CSE;
	   while ((iElem.parentNode) && (!iElem.hasbox)) {
	      scanBO(iElem);
	      iElem=iElem.parentNode;
	   }	   
	}
	
	if ((CSE!=LSE)&&(!isChild(CSE,dvHdr))&&(!isChild(CSE,dvBdy))){		
	   if (!CSE.boxItem) {
			iterElem=CSE;
			while ((iterElem.hasbox==2)&&(iterElem.parentNode))
					iterElem=iterElem.parentNode; 
			CSE.boxItem=iterElem;
			}
		iterElem=CSE.boxItem;
		if (CSE.boxItem&&(CSE.boxItem.hasbox==1))  {
			LBE=CBE;
			CBE=iterElem;
			if (CBE!=LBE) {
				applyStyles();
				if (!CBE.requireclick)
					if (CBE.fade) {
						if (ID!=null)
							clearTimeout(ID);
						ID=setTimeout("fadeIn("+CBE.fadespeed+")",CBE.delay);
					}
					else {
						if (ID!=null)
							clearTimeout(ID);
						COL=1;
						ID=setTimeout("oDv.style.visibility='visible';ID=null;",CBE.delay);						
					}
				if (CBE.IEbugfix) {hideSelects();} 
				fixposx=!isNaN(CBE.fixX)?Left(CBE)+CBE.fixX:CBE.absX;
				fixposy=!isNaN(CBE.fixY)?Top(CBE)+CBE.fixY:CBE.absY;			
				lockX=0;
				lockY=0;
				boxMove=true;
				ox=CBE.offX?CBE.offX:10;
				oy=CBE.offY?CBE.offY:10;
			}
		}
		else if (!isChild(CSE,dvHdr) && !isChild(CSE,dvBdy) && (boxMove))	{
			// The conditional here fixes flickering between tables cells.
			if ((!isChild(CBE,CSE)) || (CSE.tagName!='TABLE')) {   			
   			CBE=null;
   			if (ID!=null)
  					clearTimeout(ID);
   			fadeOut();
   			showSelects();
			}
		}
		LSE=CSE;
	}
	else if (((isChild(CSE,dvHdr) || isChild(CSE,dvBdy))&&(boxMove))) {
		totalScrollLeft=0;
		totalScrollTop=0;
		
		iterElem=CSE;
		while(iterElem) {
			if(!isNaN(parseInt(iterElem.scrollTop)))
				totalScrollTop+=parseInt(iterElem.scrollTop);
			if(!isNaN(parseInt(iterElem.scrollLeft)))
				totalScrollLeft+=parseInt(iterElem.scrollLeft);
			iterElem=iterElem.parentNode;			
		}
		if (CBE!=null) {
			boxLeft=Left(CBE)-totalScrollLeft;
			boxRight=parseInt(Left(CBE)+CBE.offsetWidth)-totalScrollLeft;
			boxTop=Top(CBE)-totalScrollTop;
			boxBottom=parseInt(Top(CBE)+CBE.offsetHeight)-totalScrollTop;
			doCheck();
		}
	}
	
	if (boxMove&&CBE) {
		// This added to alleviate bug in IE6 w.r.t DOCTYPE
		bodyScrollTop=document.documentElement&&document.documentElement.scrollTop?document.documentElement.scrollTop:document.body.scrollTop;
		bodyScrollLet=document.documentElement&&document.documentElement.scrollLeft?document.documentElement.scrollLeft:document.body.scrollLeft;
		mouseX=evt.pageX?evt.pageX-bodyScrollLet:evt.clientX-document.body.clientLeft;
		mouseY=evt.pageY?evt.pageY-bodyScrollTop:evt.clientY-document.body.clientTop;
		if ((CBE)&&(CBE.windowLock)) {
			mouseY < -oy?lockY=-mouseY-oy:lockY=0;
			mouseX < -ox?lockX=-mouseX-ox:lockX=0;
			mouseY > (SHW()[1]-oDv.offsetHeight-oy)?lockY=-mouseY+SHW()[1]-oDv.offsetHeight-oy:lockY=lockY;
			mouseX > (SHW()[0]-dvBdy.offsetWidth-ox)?lockX=-mouseX-ox+SHW()[0]-dvBdy.offsetWidth:lockX=lockX;			
		}
		oDv.style.left=((fixposx)||(fixposx==0))?fixposx:bodyScrollLet+mouseX+ox+lockX+"px";
		oDv.style.top=((fixposy)||(fixposy==0))?fixposy:bodyScrollTop+mouseY+oy+lockY+"px";		
		
	}
}

function doCheck() {	
	if (   (mouseX < boxLeft)    ||     (mouseX >boxRight)     || (mouseY < boxTop) || (mouseY > boxBottom)) {
		if (!CBE.requireclick)
			fadeOut();
		if (CBE.IEbugfix) {showSelects();}
		CBE=null;
	}
}

function pauseBox(e) {
   e?evt=e:evt=event;
	boxMove=false;
	evt.cancelBubble=true;
}

function showHideBox(e) {
	oDv.style.visibility=(oDv.style.visibility!='visible')?'visible':'hidden';
}

function hideBox(e) {
	oDv.style.visibility='hidden';
}

var COL=0;
var stopfade=false;
function fadeIn(fs) {
		ID=null;
		COL=0;
		oDv.style.visibility='visible';
		fadeIn2(fs);
}

function fadeIn2(fs) {
		COL=COL+fs;
		COL=(COL>1)?1:COL;
		oDv.style.filter='alpha(opacity='+parseInt(100*COL)+')';
		oDv.style.opacity=COL;
		if (COL<1)
		 setTimeout("fadeIn2("+fs+")",20);		
}


function fadeOut() {
	oDv.style.visibility='hidden';
	
}

function isChild(s,d) {
	while(s) {
		if (s==d) 
			return true;
		s=s.parentNode;
	}
	return false;
}

var cSrc;
function checkMove(e) {
	e?evt=e:evt=event;
	cSrc=evt.target?evt.target:evt.srcElement;
	if ((!boxMove)&&(!isChild(cSrc,oDv))) {
		fadeOut();
		if (CBE&&CBE.IEbugfix) {showSelects();}
		boxMove=true;
		CBE=null;
	}
}

function showSelects(){
	 /*
   var elements = document.getElementsByTagName("select");
   for (i=0;i< elements.length;i++){
      elements[i].style.visibility='visible';
   }
	 */
}


function hideSelects(){
   var elements = document.getElementsByTagName("select");
   for (i=0;i< elements.length;i++){
   elements[i].style.visibility='hidden';
   }
}







	var SIDEVIEW_JS = true;

	// �Ʒ��� �ҽ��ڵ�� daum.net ī���� �ڹٽ�ũ��Ʈ�� �����Ͽ����ϴ�.
	// ȸ���̸� Ŭ���� ȸ���������� �����ִ� ���̾�
	function insertHead(name, text, evt) {
		var idx = this.heads.length;
		var row = new SideViewRow(-idx, name, text, evt);
		this.heads[idx] = row;
		return row;
	}

	function insertTail(name, evt) {
		var idx = this.tails.length;
		var row = new SideViewRow(idx, name, evt);
		this.tails[idx] = row;
		return row;
	}

	function SideViewRow(idx, name, onclickEvent) {
		this.idx = idx;
		this.name = name;
		this.onclickEvent = onclickEvent;
		this.renderRow = renderRow;

		this.isVisible = true;
		this.isDim = false;
	}

	function renderRow() {
		if (!this.isVisible)
		return "";

		var str = "<tr><td id='sideViewRow_"+this.name+"'><table height='25' border='0' cellpadding='0' cellspacing='0' width='96%' align='center'><tr onmouseOver=\"this.style.backgroundColor='#E2E8FA'\" onmouseOut=\"this.style.backgroundColor=''\"><td>&nbsp;&nbsp;&nbsp;<span style='color: #A0A0A0;  font-family: ����; font-size: 11px;'>"+this.onclickEvent+"</span></td><tr></table></td></tr>";
		return str;
	}

	function showSideView(curObj, no, cookies_meId, me_id, me_name, me_email, me_homepage, me_paper, ji_paperUse, ji_email, useUTF) {
		var sideView = new SideView('nameContextMenu', curObj, no, cookies_meId, me_id, me_name, me_email, me_homepage, me_paper, ji_paperUse, ji_email, useUTF);
		sideView.showLayer();
	}


	function SideView(targetObj, curObj, no, cookies_meId, me_id, me_name, me_email, me_homepage, me_paper, ji_paperUse, ji_email, useUTF) {

		this.targetObj = targetObj;
		this.curObj = curObj;
		this.no = no;
		this.cookies_meId = cookies_meId;
		this.me_id = me_id;
		me_name = me_name.replace(/��/g,"");
		this.me_name = me_name;
		this.me_email = me_email;
		this.me_homepage = me_homepage;
		this.me_paper = me_paper;
		this.ji_paperUse = ji_paperUse;
		this.ji_email = ji_email;
		this.useUTF = useUTF;
		this.showLayer = showLayer;
		this.makeNameContextMenus = makeNameContextMenus;
		this.heads = new Array();
		this.insertHead = insertHead;
		this.tails = new Array();
		this.insertTail = insertTail;
		this.getRow = getRow;
		this.hideRow = hideRow;		
		this.dimRow = dimRow;


		if (no && ji_paperUse == '0' && me_paper == 'False' && cookies_meId != '') 
		this.insertTail("memo", "<a href=\"javascript:show_paper('"+me_id+"');\">����������</a>");
		if (me_email && ji_email == '0') 
		this.insertTail("mail", "<a href=\"javascript:show_mail('"+me_name+"','"+me_email+"','"+cookies_meId+"','"+useUTF+"');\">���Ϻ�����</a>");
		if (me_email && ji_email == '1') 
		this.insertTail("mail", "<a href=\"mailto:"+me_email+"\">���Ϻ�����</a>");
		if (me_homepage) 
		this.insertTail("me_homepage", "<a href=\"javascript:;\" onclick=\"window.open('"+me_homepage+"');\">Ȩ������</a>");

	}






	function showLayer() {
		clickAreaCheck = true;
		var oSideViewLayer = document.getElementById(this.targetObj);
		var oBody = document.body;

		if (oSideViewLayer == null) {
		oSideViewLayer = document.createElement("DIV");
		oSideViewLayer.id = this.targetObj;
		oSideViewLayer.style.position = 'absolute';
		oBody.appendChild(oSideViewLayer);
		}
		oSideViewLayer.innerHTML = this.makeNameContextMenus();

		if (getAbsoluteTop(this.curObj) + this.curObj.offsetHeight + oSideViewLayer.scrollHeight + 5 > oBody.scrollHeight)
		oSideViewLayer.style.top = getAbsoluteTop(this.curObj) - oSideViewLayer.scrollHeight;
		else
		oSideViewLayer.style.top = getAbsoluteTop(this.curObj) + this.curObj.offsetHeight;

		oSideViewLayer.style.left = getAbsoluteLeft(this.curObj) - this.curObj.offsetWidth + 14;

		divDisplay(this.targetObj, 'block');

		selectBoxHidden(this.targetObj);
	}

	function getAbsoluteTop(oNode) {
		var oCurrentNode=oNode;
		var iTop=0;
		while(oCurrentNode.tagName!="BODY") {
		iTop+=oCurrentNode.offsetTop - oCurrentNode.scrollTop;
		oCurrentNode=oCurrentNode.offsetParent;
		}
		return iTop;
	}

	function getAbsoluteLeft(oNode) {
		var oCurrentNode=oNode;
		var iLeft=0;
		iLeft+=oCurrentNode.offsetWidth;
		while(oCurrentNode.tagName!="BODY") {
		iLeft+=oCurrentNode.offsetLeft;
		oCurrentNode=oCurrentNode.offsetParent;
		}
		return iLeft;
	}


	function makeNameContextMenus() {
		var str = "<table border='0' cellpadding='0' cellspacing='0' width='110' style='border:1px solid #BBBBBB;' bgcolor='#FFFFFF'>";

		var i=0;
		for (i=this.heads.length - 1; i >= 0; i--)
		str += this.heads[i].renderRow();
			 
		var j=0;
		for (j=0; j < this.tails.length; j++)
		str += this.tails[j].renderRow();

		str += "</table>";
		return str;
	}

	function getRow(name) {
		var i = 0;
		var row = null;
		for (i=0; i<this.heads.length; ++i) {
		row = this.heads[i];
		if (row.name == name) return row;
		}

		for (i=0; i<this.tails.length; ++i) {
		row = this.tails[i];
		if (row.name == name) return row;
		}
		
		return row;
	}

	function hideRow(name) {
		var row = this.getRow(name);
		if (row != null)
		row.isVisible = false;
	}

	function dimRow(name) {
		var row = this.getRow(name);
		if (row != null)
		row.isDim = true;
	}


	// Internet Explorer���� ����Ʈ�ڽ��� ���̾ ��ĥ�� ���̾ ����Ʈ �ڽ� �ڷ� ���� ������ �ذ��ϴ� �Լ�
	// ���̾ ����Ʈ �ڽ��� ħ���ϸ� ����Ʈ �ڽ��� hidden ��Ŵ
	// <div id=LayerID style="display:none; position:absolute;" onpropertychange="selectBoxHidden('LayerID')">
	function selectBoxHidden(layer_id) {
		//var ly = eval(layer_id);
		var ly = document.getElementById(layer_id);

		// ���̾� ��ǥ
		var ly_left   = ly.offsetLeft;
		var ly_top= ly.offsetTop;
		var ly_right  = ly.offsetLeft + ly.offsetWidth;
		var ly_bottom = ly.offsetTop + ly.offsetHeight;

		// ����Ʈ�ڽ��� ��ǥ
		var el;

		for (i=0; i<document.forms.length; i++) {
			for (k=0; k<document.forms[i].length; k++) {
				el = document.forms[i].elements[k];
				if (el.type == "select-one") {
					var el_left = el_top = 0;
					var obj = el;
					if (obj.offsetParent) {
						while (obj.offsetParent) {
						el_left += obj.offsetLeft;
						el_top  += obj.offsetTop;
						obj = obj.offsetParent;
						}
					}


					el_left   += el.clientLeft;
					el_top+= el.clientTop;
					el_right  = el_left + el.clientWidth;
					el_bottom = el_top + el.clientHeight;

					// ��ǥ�� ���� ���̾ ����Ʈ �ڽ��� ħ�������� ����Ʈ �ڽ��� hidden ��Ŵ
					if ( (el_left >= ly_left && el_top >= ly_top && el_left <= ly_right && el_top <= ly_bottom) || 
					 (el_right >= ly_left && el_right <= ly_right && el_top >= ly_top && el_top <= ly_bottom) ||
					 (el_left >= ly_left && el_bottom >= ly_top && el_right <= ly_right && el_bottom <= ly_bottom) ||
					 (el_left >= ly_left && el_left <= ly_right && el_bottom >= ly_top && el_bottom <= ly_bottom) ||
					 (el_top <= ly_bottom && el_left <= ly_left && el_right >= ly_right)
					)
				
					el.style.visibility = 'hidden';
			
				}
			}
		}
	}

	// ���߾��� ����Ʈ �ڽ��� ��� ���̰� ��
	function selectBoxVisible() {
		for (i=0; i<document.forms.length; i++) {
			for (k=0; k<document.forms[i].length; k++) {
				el = document.forms[i].elements[k];
				if (el.type == "select-one" && el.style.visibility == 'hidden')
				el.style.visibility = 'visible';
			}
		}
	}


	function getAbsoluteTop(oNode) {
		var oCurrentNode=oNode;
		var iTop=0;
		while(oCurrentNode.tagName!="BODY") {
		iTop+=oCurrentNode.offsetTop - oCurrentNode.scrollTop;
		oCurrentNode=oCurrentNode.offsetParent;
		}
		return iTop;
	}


	function getAbsoluteLeft(oNode) {
		var oCurrentNode=oNode;
		var iLeft=0;
		iLeft+=oCurrentNode.offsetWidth;
		while(oCurrentNode.tagName!="BODY") {
		iLeft+=oCurrentNode.offsetLeft;
		oCurrentNode=oCurrentNode.offsetParent;
		}
		return iLeft;
	}

	function divDisplay(id, act) {
		selectBoxVisible();

		document.getElementById(id).style.display = act;
	}

	function hideSideView() {
		if (document.getElementById("nameContextMenu"))
		divDisplay ("nameContextMenu", 'none');
	}

	var clickAreaCheck = false;
	document.onclick = function() {
		if (!clickAreaCheck) 
		hideSideView();
		else 
		clickAreaCheck = false;
	}





	// ���� ����Ʈ�ڽ� ȿ�� by �˸� (2007/11/07)
	// http://www.alik.info

	var SLB_cnt = 0;

	function SLB(url, type)
	{
		var a = document.getElementById('SLB_film');
		var b = document.getElementById('SLB_content');
		var c = document.getElementById('SLB_loading');
		if(url) {
			a.style.top = 0;
			a.style.left = 0;
			a.style.display = "";
			if (document.documentElement.scrollHeight > document.body.scrollHeight) {
				a.style.height = document.documentElement.scrollHeight + 'px';
			} else { 
				a.style.height = document.body.scrollHeight + 'px';
			}
			c.style.display = "block";
			SLB_setCenter(c,true);
			if(type == 'image') {
				b.innerHTML="<img src=" + url + " class='SLB_center' onload='SLB_setCenter(this);' />";
				if(arguments[2]) a.onclick = function () { SLB() };
				if(arguments[3]) b.innerHTML += "<div class='SLB_caption'>"+ arguments[3] +"</div>";;
			} else if (type == 'iframe') {
				b.innerHTML="<iframe id='SLB_iframe' name='SLB_target' src=" + url + " width="+ arguments[2] +" height="+ arguments[3] +" class='SLB_center' marginwidth='0' marginheight='0' frameborder='0' vspace='0' hspace='0' onload='tryReHeight("+arguments[5]+");'/></iframe>";
				if(arguments[4]) {
					b.innerHTML += "<div class='SLB_close' onclick='SLB();' title='�ݱ�'>close</div>";
				}
				b.onclick = ''; b.firstChild.style.cursor = 'default';
			} else if (type='html'){
				b.innerHTML = url;
				SLB_setCenter(b.firstChild);
				if(arguments[2]) b.onclick = '';
			}
			hideSelect();
		} else {
			a.onclick = '';
			a.style.display = "none";
			a.style.height = '100%';
			a.style.width = '100%';
			b.innerHTML = "";
			b.onclick = function () { SLB() };
			c.style.display = "none";
			showSelect();
			SLB_cnt = 0;
		}
	}

	function SLB_setCenter(obj) {
		if (obj) {
			var h = (window.innerHeight || self.innerHeight || document.documentElement.clientHeight || document.body.clientHeight);
			var w = (window.innerWidth || self.innerWidth || document.documentElement.clientWidth || document.body.clientWidth);
			var l = ((window.pageXOffset || document.documentElement.scrollLeft || document.body.scrollLeft) + ((w-(obj.width||parseInt(obj.style.width)||obj.offsetWidth))/2));
			var t = ((window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop) + ((h-(obj.height||parseInt(obj.style.height)||obj.offsetHeight))/2));
			if((obj.width||parseInt(obj.style.width)||obj.offsetWidth) >= w) l = 0;
			if((obj.height||parseInt(obj.style.height)||obj.offsetHeight) >= h) t = (window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop);
			document.getElementById('SLB_content').style.left = l + "px";
			if(SLB_cnt == 0) {
				document.getElementById('SLB_content').style.top = t + "px";
				if(document.getElementById('SLB_content').offsetHeight >= h - 20) {
					SLB_cnt ++;
				}
				if(obj.nextSibling && (obj.nextSibling.className == 'SLB_close' || obj.nextSibling.className == 'SLB_caption')) {
					obj.nextSibling.style.display = 'block';
					if((t - (window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop))>(obj.nextSibling.offsetHeight/2)) {
						document.getElementById('SLB_content').style.top = parseInt(document.getElementById('SLB_content').style.top) - (obj.nextSibling.offsetHeight/2) + "px";
					}
				}
			}
			obj.style.visibility = 'visible';
			if(!arguments[1]) {
				document.getElementById('SLB_loading').style.display = "none";
			} else {
				obj.style.left = l + "px";
				obj.style.top = t + "px";
			}
		}
	}

	function hideSelect() {
		var windows = window.frames.length;
		var selects = document.getElementsByTagName("SELECT");
		for (i=0;i < selects.length ;i++ )
		{
			selects[i].style.visibility = "hidden";
		}
		if (windows > 0) {
			for(i=0; i < windows; i++) {
				try {
					var selects = window.frames[i].document.getElementsByTagName("SELECT");
					for (j=0;j<selects.length ;j++ )
					{
						selects[j].style.visibility = "hidden";
					}
				} catch (e) {}
			}
		}
	}

	function showSelect() {
		var windows = window.frames.length;
		var selects = document.getElementsByTagName("SELECT");
		for (i=0;i < selects.length ;i++ )
		{
			selects[i].style.visibility = "visible";
		}
		if (windows > 0) {
			for(i=0; i < windows; i++) {
				try {
					var selects = window.frames[i].document.getElementsByTagName("SELECT");
					for (j=0;j<selects.length ;j++ )
					{
						selects[j].style.visibility = "visible";
					}
				} catch (e) {}
			}
		}
	}

	function tryReHeight(sign) {
		var getFFVersion=navigator.userAgent.substring(navigator.userAgent.indexOf("Firefox")).split("/")[1];
		var FFextraHeight=parseFloat(getFFVersion)>=0.1? 16 : 0;
		var currentfr=document.getElementById('SLB_iframe');
		if(sign == true) {
			try {
				if (currentfr.contentDocument && currentfr.contentDocument.body.offsetHeight) {
					setIframeSize(currentfr.contentDocument.body.offsetHeight+FFextraHeight);
				} else if (currentfr.Document && currentfr.Document.body.scrollHeight) {
					setIframeSize(currentfr.Document.body.scrollHeight);
				}
			}catch(e) { }
		} else {
			SLB_setCenter(currentfr);
		}
	}

	function setIframeSize(h, w) {
		SLB_cnt = 0;
		var ifr = currentfr=document.getElementById('SLB_iframe');
		if (ifr) {
			if(w) {
				ifr.width = w;
			}
			if(h) {
				ifr.height = h;
			}
			SLB_setCenter(ifr);
		}
	}

	var prevOnScroll = window.onscroll;
	window.onscroll = function () {
		//if(prevOnScroll != undefined) prevOnScroll();
		if (document.documentElement.scrollHeight > document.body.scrollHeight) {
			document.getElementById('SLB_film').style.height = document.documentElement.scrollHeight + 'px';
		} else { 
			document.getElementById('SLB_film').style.height = document.body.scrollHeight + 'px';
		}
		document.getElementById('SLB_film').style.width = document.body.scrollWidth + 'px';
		SLB_setCenter(document.getElementById('SLB_content').firstChild);
	}

	var prevOnResize = window.onresize;
	window.onresize = function () {
		//if(prevOnResize != undefined) prevOnResize();
		if (document.documentElement.scrollHeight > document.body.scrollHeight) {
		//	document.getElementById('SLB_film').style.height = document.documentElement.scrollHeight + 'px';
		} else { 
			document.getElementById('SLB_film').style.height = document.body.scrollHeight + 'px';
		}
		//document.getElementById('SLB_film').style.width = document.body.offsetWidth + 'px';
		//SLB_setCenter(document.getElementById('SLB_content').firstChild);
	}





	function FlashPlayer(FlashName, width, height) {
		document.write('<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,29,0" width="'+ width +'" height="'+ height +'">');
		document.write('<param name="movie" value="'+ FlashName +'">');
		document.write('<param name="quality" value="high">');
		document.write('<param name=WMode value="Transparent">');
		document.write('<embed src="'+ FlashName +'" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="'+ width +'" height="'+ height +'"></embed>');
		document.write('</object>');
	}

	function MediaPlayer(MediaName) {
		document.write('<OBJECT ID="MediaPlay" classid="CLSID:22d6f312-b0f6-11d0-94ab-0080c74c7e95" codebase="http://activex.microsoft.com/activex/controls/mplayer/en/nsmp2inf.cab#Version=5,1,52,701" standby="Loading Microsoft Windows Media Player components..." type="application/x-oleobject">');
		document.write('<PARAM NAME="FileName" VALUE="'+ MediaName +'"');
		document.write('<PARAM NAME="AnimationatStart" VALUE="false">');
		document.write('<PARAM NAME="TransparentatStart" VALUE="true">');
		document.write('<PARAM NAME="AutoStart" VALUE="true">');
		document.write('<PARAM NAME="AutoSize" VALUE="true">');
		document.write('<PARAM NAME="ShowControls" VALUE="true">');
		document.write('<PARAM NAME="ShowStatusBar" VALUE="ture">');
		document.write('<PARAM NAME="Volume" value="0">');
		document.write('</OBJECT>');
	}


  function encodeURL(str){
      var s0, i, s, u;
      s0 = "";
      for (i = 0; i < str.length; i++){
          s = str.charAt(i);
          u = str.charCodeAt(i);
          if (s == " "){s0 += "+";}
          else {
              if ( u == 0x2a || u == 0x2d || u == 0x2e || u == 0x5f || ((u >= 0x30) && (u <= 0x39)) || ((u >= 0x41) && (u <= 0x5a)) || ((u >= 0x61) && (u <= 0x7a))){
                  s0 = s0 + s;
              }
              else {
                  if ((u >= 0x0) && (u <= 0x7f)){
                      s = "0"+u.toString(16);
                      s0 += "%"+ s.substr(s.length-2);
                  }
                  else if (u > 0x1fffff){
                      s0 += "%" + (oxf0 + ((u & 0x1c0000) >> 18)).toString(16);
                      s0 += "%" + (0x80 + ((u & 0x3f000) >> 12)).toString(16);
                      s0 += "%" + (0x80 + ((u & 0xfc0) >> 6)).toString(16);
                      s0 += "%" + (0x80 + (u & 0x3f)).toString(16);
                  }
                  else if (u > 0x7ff){
                      s0 += "%" + (0xe0 + ((u & 0xf000) >> 12)).toString(16);
                      s0 += "%" + (0x80 + ((u & 0xfc0) >> 6)).toString(16);
                      s0 += "%" + (0x80 + (u & 0x3f)).toString(16);
                  }
                  else {
                      s0 += "%" + (0xc0 + ((u & 0x7c0) >> 6)).toString(16);
                      s0 += "%" + (0x80 + (u & 0x3f)).toString(16);
                  }
              }
          }
      }

      return s0;
  }

   


  function decodeURL(str){
      var s0, i, j, s, ss, u, n, f;
      s0 = "";
      for (i = 0; i < str.length; i++){
          s = str.charAt(i);
          if (s == "+"){s0 += " ";}
          else {
              if (s != "%"){s0 += s;}
              else{
                  u = 0;
                  f = 1;
                  while (true) {
                      ss = "";
                          for (j = 0; j < 2; j++ ) {
                              sss = str.charAt(++i);
                              if (((sss >= "0") && (sss <= "9")) || ((sss >= "a") && (sss <= "f")) || ((sss >= "A") && (sss <= "F"))) {
                                  ss += sss;
                              } else {--i; break;}
                          }
                      n = parseInt(ss, 16);
                      if (n <= 0x7f){u = n; f = 1;}
                      if ((n >= 0xc0) && (n <= 0xdf)){u = n & 0x1f; f = 2;}
                      if ((n >= 0xe0) && (n <= 0xef)){u = n & 0x0f; f = 3;}
                      if ((n >= 0xf0) && (n <= 0xf7)){u = n & 0x07; f = 4;}
                      if ((n >= 0x80) && (n <= 0xbf)){u = (u << 6) + (n & 0x3f); --f;}
                      if (f <= 1){break;}
                      if (str.charAt(i + 1) == "%"){ i++ ;}
                      else {break;}
                  }
              s0 += String.fromCharCode(u);
              }
          }
      }

      return s0;
  }






	function MM_preloadImages() { //v3.0
		var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
			var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
			if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
	}

	function MM_swapImgRestore() { //v3.0
		var i,x,a=document.MM_sr; for(i=0;a&&i<a.length&&(x=a[i])&&x.oSrc;i++) x.src=x.oSrc;
	}

	function MM_findObj(n, d) { //v4.01
		var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
			d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
		if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
		for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
		if(!x && d.getElementById) x=d.getElementById(n); return x;
	}

	function MM_swapImage() { //v3.0
		var i,j=0,x,a=MM_swapImage.arguments; document.MM_sr=new Array; for(i=0;i<(a.length-2);i+=3)
		 if ((x=MM_findObj(a[i]))!=null){document.MM_sr[j++]=x; if(!x.oSrc) x.oSrc=x.src; x.src=a[i+2];}
	}


	function MM_reloadPage(init) {  
		if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
			document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
		else if (innerWidth!=document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
	}
	MM_reloadPage(true);



	function MM_showHideLayers() { //v3.0
		var i,p,v,obj,args=MM_showHideLayers.arguments;
		for (i=0; i<(args.length-2); i+=3) if ((obj=MM_findObj(args[i]))!=null) { v=args[i+2];
			if (obj.style) { obj=obj.style; v=(v=='show')?'visible':(v='hide')?'hidden':v; }
			obj.visibility=v; }
	}




	function allblur() {
		for (i = 0; i < document.links.length; i++)
			document.links[i].onfocus = document.links[i].blur;
	}

	//window.onload = allblur;


	function ShowProgress(si_upload) {

		if (si_upload == "1") {

			strAppVersion = navigator.appVersion; 

			winstyle = "dialogWidth=385px; dialogHeight:150px; center:yes"; 
			window.showModelessDialog("../inc/show_progress.asp?nav=ie", null, winstyle);
		}	
		
	}


	function access_check(cl_name) {
		alert(cl_name +'�� �̿��Ͻ� �� �����ϴ�.')
	}



	function show_paper(me_id) { 

	 var targetSTR = "../../Jsource/Jsend/paperSend_pop.asp";
		targetSTR += "?me_id="+me_id;

		SLB(targetSTR,'iframe', 430, 404, false, true);

	}


	function show_mail(To_name, To_email, From_MeId, encode) { 

		var targetSTR;
		if (encode != '') To_name = encodeURL(To_name);

		targetSTR = "../../Jsource/Jsend/mailing.asp?To_name="+To_name+"&To_email="+To_email;
		targetSTR +="&From_MeId="+From_MeId;

		SLB(targetSTR,'iframe', 430, 466, false, true);

	}


	function executePrint(URL, w, h) {
    var URL, str, w, h;
    var winl = (screen.width - w) / 2;
    var wint = (screen.height - h) / 2;

    str="toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,";
    str=str+"resizable=no,copyhistory=no,fullscreen=no,";
    str=str+"width="+w+",height="+h+",";
    str=str+"top="+wint+",left="+winl;
    window.open(URL,'print',str);
	}



	function centerPop1(URL, w, h) {
		var URL, str, w, h;
		var winl = (screen.width - w) / 2;
		var wint = (screen.height - h) / 2;

		str="toolbar=no,location=no,directories=no,status=yes,menubar=no,scrollbars=no,";
		str=str+"resizable=no,copyhistory=no,fullscreen=no,";
		str=str+"width="+w+",height="+h+",";
		str=str+"top="+wint+",left="+winl;
		window.open(URL,'',str);
	}


	function centerPop2(URL, w, h) {
		var URL, str, w, h;
		var winl = (screen.width - w) / 2;
		var wint = (screen.height - h) / 2;

		str="toolbar=no,location=no,directories=no,status=yes,menubar=no,scrollbars=yes,";
		str=str+"resizable=no,copyhistory=no,fullscreen=no,";
		str=str+"width="+w+",height="+h+",";
		str=str+"top="+wint+",left="+winl;
		window.open(URL,'centerPop',str);
	}


	function LoginCheck(page_location) {
		//alert("�α��� �� �̿��Ͻ� �� �ֽ��ϴ�.");
		location.href='../login/InsideLogin.asp?'+page_location;
		return;
	}
