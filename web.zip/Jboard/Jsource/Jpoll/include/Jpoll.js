

// ���� ����


	var x = 0 
	var y = 0
	drag = 0
	move = 0
	window.document.onmousemove = mouseMove
	window.document.onmousedown = mouseDown 
	window.document.onmouseup = mouseUp 
	window.document.ondragstart = mouseStop 
	function mouseUp() { 
		move = 0 
	}
	function mouseDown() {
		if (drag) {
		clickleft = window.event.x - parseInt(dragObj.style.left) 
		clicktop = window.event.y - parseInt(dragObj.style.top) 
		dragObj.style.zIndex += 1 
		move = 1 
		} 
	} 
	function mouseMove() { 
		if (move) { 
		dragObj.style.left = window.event.x - clickleft 
		dragObj.style.top = window.event.y - clicktop 
		} 
	} 
	function mouseStop() { 
		window.event.returnValue = false 
	}
	function Hide(divid) { 
		divid.style.visibility = "hidden"; 
	} 
	function None(divid) { 
		divid.style.visibility = "hidden"; 
	}


	function Show_comment(divid, pc_idx) {
		var cdf = document.content_delete_form;
		divid.style.visibility = "visible";
		divid.style.top = document.body.scrollTop + 400;
		divid.style.left = 550;
		cdf.jb_pwd.focus();
		cdf.pc_idx.value = pc_idx;
		if (cdf.submit.value != undefined) {
			cdf.submit.value = '����';
		}
	}



	function ShowProcess(divid) {

		var winl = (screen.width - 214) / 2;
		var wint = (screen.height - 250) / 2;

		divid.style.visibility = "visible";
		divid.style.top = wint;
		divid.style.left = winl;
	
	} 


// ���� ��








// POLL �� ����



	function PollAuCheck(cl_name) {
		alert(cl_name+"�� ��ǥ�� ������ �� �ִ� ������ �����ϴ�.");
		return;
	}


	function ResultAuCheck(cl_name) {
		alert(cl_name+"�� ����� �� �� �ִ� ������ �����ϴ�.");
		return;
	}


	function all_check() {      
		
		var len = document.pagesize_form.jb_idx.length;
		var jb_idx = document.pagesize_form.jb_idx; 
	
		for ( var i=0;i<len; i++ ) {
			if (jb_idx[i].checked)	{
				jb_idx[i].checked = false;
			}	else {
				jb_idx[i].checked = true;
			}
			
		}

	}



	function check_all(bool) {      
		
		var len = document.pagesize_form.jb_idx.length;
		var jb_idx = document.pagesize_form.jb_idx; 
			 
		if (bool) {          
		for(i=0; i<len; i++) {            
			jb_idx[i].checked = true;
			}         
		return 
		}  
		
		else {          
			for(i=0; i<len; i++) {            
				jb_idx[i].checked = false;
			}          
			return    
		}   
	}






	function check_remove(pi_num, gotopage, ad_page, folder_name) {
		var pf = document.pagesize_form;
		var submitFlag = 0;
			for(i = 0; i < pf.jb_idx.length; ++i) {
				if(pf.jb_idx[i].name == 'jb_idx') {
					if(pf.jb_idx[i].checked == true) {
						submitFlag = 1;
					break;
					}
				}
			}
		if(submitFlag){

			answer1 = confirm("���� �����Ͻðڽ��ϱ�?");
			
			if(answer1 == true) {
				var	targetSTR = "../Jboard/remove_pro.asp?pi_num="+pi_num+"&gotopage="+gotopage;
				var	targetSTR = targetSTR+"&ad_page="+ad_page+"&folder_name="+folder_name;
				document.pagesize_form.action = targetSTR;
				document.pagesize_form.submit();
				return;
			}
			else {
				alert("��ҵǾ����ϴ�.");
				}
			}

		else {
			alert("������ �����ʾҽ��ϴ�."); 
		return;
		}
	}



// POLL �� ��








// RESULT �� ����


	function content_CategorySelect(pi_num, ad_page, pi_CaNum) {
		var cf = document.content_form;
		var var_sort = cf.pi_num.value;
		var sort_len = var_sort.length - 5; //pi_num�� ���̸� ����

		pi_num = var_sort.substring(4+sort_len);
		pi_num = var_sort.substring(0,4);

		if(pi_num == "") {
			pi_num = pi_CaNum;
			pi_num = '';
		}

		var targetSTR = "list.asp?pi_num="+pi_num+"&pi_num="+pi_num;

		if (ad_page != '') {
			targetSTR += "&ad_page="+ad_page;
		}

		window.location.href = targetSTR;		

	}




	function remove_admin(urlpath, gubun){

		if (confirm("���� "+gubun+"�� �����Ͻðڽ��ϱ�?")) {
			
			location.href(urlpath);
		}
		else {
			alert("������ ��ҵǾ����ϴ�.");
		}
	}


	function remove_member(urlpath, gubun){

		if (confirm("���� "+gubun+"�� �����Ͻðڽ��ϱ�?")) {
			
			location.href(urlpath);
		}
		else {
			alert("������ ��ҵǾ����ϴ�.");
		}
	}




	function remove_comment(pi_num, pc_idx, gotopage, ad_page, mode, page_name) {
		var targetSTR;
	
		targetSTR = page_name+".asp?pi_num="+pi_num+"&pc_idx="+pc_idx+"&gotopage="+gotopage;
		targetSTR +="&ad_page="+ad_page;
		targetSTR +="&mode="+mode;
		window.location.href = targetSTR;
	}




	function remove_submit() {

		var cd = document.content_delete_form;

		if (cd.jb_pwd.value == "") {
			alert("�н����带 �Է��ϼ���.");
			cd.jb_pwd.focus();
			return false;
		}

	}





	var Trans = false; 
	function add_pollComment(me_id) {
		
		var f = document.comm_form;

		if (f.pc_name.value == "") {
			alert("�̸��� �Է����ּ���.");
			f.pc_name.focus();
			return;
		}

		if (me_id == '')	{
			if (f.pc_pwd.value == "") {
				alert("�н����带 �Է����ּ���.");
				f.pc_pwd.focus();
				return;
			}
		}

		if (f.pc_content.value == "") {
			alert("��Ʈ�� �Է����ּ���.");
			f.pc_content.focus();
			return;
		}

		if (Trans == false) {

			ShowProcess(JboardProcess);

			f.action = "../../Jsource/Jpoll/comment_write_pro.asp";
			f.method = "post";
			f.target = "ProcessFm";
			f.submit();
		}

		Trans = true;
	}




	function poll_link(pi_num, gotopage, ad_page, file_name) {
		var targetSTR;
	
		window.location.href = file_name+".asp?pi_num="+pi_num+"&gotopage="+gotopage+"&ad_page="+ad_page;

	}


	function paging_link(page_name, gotopage, pi_num, ad_page) {
		var targetSTR;
	
		targetSTR = page_name+"?gotopage="+gotopage+"&pi_num="+pi_num+"&ad_page="+ad_page;
		window.location.href = targetSTR;
	}



	function result_poll(pi_num, gotopage, ad_page, folder_name, file_name) {

		var pi_num, gotopage, ad_page, folder_name, file_name, targetSTR;
		var pf = document.poll_form;
		var submitFlag = 0;
		
		targetSTR = file_name+".asp?pi_num="+pi_num+"&gotopage="+gotopage;
		targetSTR = targetSTR+"&ad_page="+ad_page+"&folder_name="+folder_name;
		targetSTR = targetSTR+"&screen_width="+screen.width;

		for(i = 0; i < pf.elements.length; ++i) {
			if(pf.elements[i].name == 'po_idx') {
				if(pf.elements[i].checked == true) {
					submitFlag = 1;
				break;
				}
			}
		}

		if(submitFlag){
			pf.method = "post";
			pf.action = targetSTR;
			pf.submit();
		}
		else{
			alert(" �����׸��� �������� �ʾҽ��ϴ� "); 
		return;
		}		
		
	}


// RESULT �� ��


