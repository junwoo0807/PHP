

// ���� ����


function allblur() {
	for (i = 0; i < document.links.length; i++)
    document.links[i].onfocus = document.links[i].blur;
}

//window.onload = allblur;


// ���� ��






// SETUP_1 �� ����

  function encodeURL(str){
      var s0, i, s, u;
      s0 = "";
      for (i = 0; i < str.length; i++){
          s = str.charAt(i);
          u = str.charCodeAt(i);
          if (s == " "){s0 += "+";}
          else {
              if ( u == 0x2a || u == 0x2d || u == 0x2e || u == 0x5f || ((u >= 0x30) && (u <= 0x39)) || ((u >= 0x41) && (u <= 0x5a)) || ((u >= 0x61) && (u <= 0x7a))){
                  s0 = s0 + s;
              }
              else {
                  if ((u >= 0x0) && (u <= 0x7f)){
                      s = "0"+u.toString(16);
                      s0 += "%"+ s.substr(s.length-2);
                  }
                  else if (u > 0x1fffff){
                      s0 += "%" + (oxf0 + ((u & 0x1c0000) >> 18)).toString(16);
                      s0 += "%" + (0x80 + ((u & 0x3f000) >> 12)).toString(16);
                      s0 += "%" + (0x80 + ((u & 0xfc0) >> 6)).toString(16);
                      s0 += "%" + (0x80 + (u & 0x3f)).toString(16);
                  }
                  else if (u > 0x7ff){
                      s0 += "%" + (0xe0 + ((u & 0xf000) >> 12)).toString(16);
                      s0 += "%" + (0x80 + ((u & 0xfc0) >> 6)).toString(16);
                      s0 += "%" + (0x80 + (u & 0x3f)).toString(16);
                  }
                  else {
                      s0 += "%" + (0xc0 + ((u & 0x7c0) >> 6)).toString(16);
                      s0 += "%" + (0x80 + (u & 0x3f)).toString(16);
                  }
              }
          }
      }

      return s0;
  }


	function Show(divid) {

		var winl = (screen.width - 214) / 2;
		var wint = (screen.height - 250) / 2;

		divid.style.visibility = "visible";
		divid.style.top = wint;
		divid.style.left = winl;
	
	} 


	function IsDBpass(pass_str) {

		var nIndex;
		var ascChrCurrent;
		var bReturn;

		bReturn = true;	

		for ( nIndex = 0; nIndex < pass_str.length; nIndex++)	{
			ascChrCurrent = pass_str.charAt(nIndex);
			if ( (ascChrCurrent >= '0' && ascChrCurrent <= '9'	) || (ascChrCurrent >= '0' && ascChrCurrent <= 'z') || (ascChrCurrent >= '0' && ascChrCurrent <= 'Z') ) {
				bReturn = true;	
			}	else {
				bReturn = false;
				break;
			}
		}
		
		return bReturn;
	}





	function sendit_1() {

		var se_1 = document.setup1_form;

		if (se_1.host_name.value == "") {
			 alert("[Host Name]�� �������ּ���.");
			 se_1.host_name.focus();
			 return false;
		}
		if (se_1.db_name.value == "") {
			 alert("[DB Nname]�� �������ּ���.");
			 se_1.db_name.focus();
			 return false;
		}
		if (se_1.user_id.value == "") {
			 alert("[User ID]�� �������ּ���.");
			 se_1.user_id.focus();
			 return false;
		}
		if (se_1.password.value == "") {
			 alert("[Password]�� �������ּ���.");
			 se_1.password.focus();
			 return false;
		/*
		} else {
			if (IsDBpass(se_1.password.value)  == false) {
			 alert("[Password]�� Ư�����ڸ� �Է��Ͻø� �ȵ˴ϴ�.");
			 se_1.password.focus();
			 return false;
			}		
		*/
		
		}

		Show(processing);
		se_1.action = "setup1_pro.asp";
		se_1.method = "post";
		dbconn_check();
			 
}



	function dbconn_check() {

		var dc_1 = document.setup1_form;

		host_name = dc_1.host_name.value;
		db_name   = dc_1.db_name.value;
		user_id		= dc_1.user_id.value;
		password  = dc_1.password.value;
		
		targetSTR = "include/dbconn_check.asp?host_name="+host_name;
		targetSTR = targetSTR+"&db_name="+db_name+"&user_id="+user_id+"&password="+encodeURL(password);
		HiddenFm.location.href = targetSTR;
	
	}


	

// SETUP_1 �� ��





// SETUP_2 �� ����



	function Validatead_id(strad_id) {
			
		bRetNo = true;
		if ( ( strad_id.length <= 0 ) || ( strad_id.length > 12 ) || (Isad_id(strad_id)  == false ) ) {
			bRetNo = false;
		}
			return bRetNo;
	}



	function Isad_id(strad_id) {
	var nIndex;
	var chrCurrent;
	var ascChrCurrent;
	var strInvalid;
	var bReturn;

	bReturn = true;
		

		for ( nIndex = 0; nIndex < strad_id.length; nIndex++)	{

			ascChrCurrent = strad_id.charAt(nIndex);

			if ( (ascChrCurrent >= '0' && ascChrCurrent <= '9'	) || (ascChrCurrent >= '0' && ascChrCurrent <= 'z') || (ascChrCurrent >= '0' && ascChrCurrent <= 'Z') )
			{
				bReturn = true;	
			}
			else {
				bReturn = false;
				break;
			}
		}
		
		if ( bReturn && (( strad_id.length < 4) || ( strad_id.length > 12 ) )) {
			bReturn = false;
		}
		return bReturn;
	}



	function Isad_pass( strad_pass ) {
	var se_2 = document.setup2_form
	var bRetNo;


	if ( strad_pass.length >= 4 && strad_pass.length <= 12  ) {	
		if ((strad_pass == se_2.ad_id.value) || (strad_pass == "1234") || (strad_pass == se_2.ad_id.value + "1234")) {
				return false;
			}
			bRetNo = true;
		}
		else	{
			bRetNo = false;
		}
		return bRetNo;
	}





	function component_check() {
		var dc_2 = document.setup2_form

		si_upload = dc_2.si_upload.value;

		targetSTR = "include/component_check.asp?si_upload="+si_upload;
		HiddenFm.location.href = targetSTR;
	
	}




	function sendit_2() {
		var se_2 = document.setup2_form
		var string_1 = se_2.ad_name.value;
		var string_2 = se_2.ad_SiteName.value;

		if (se_2.ad_id.value == "") {
			 alert("[������ ID]�� �������ּ���.");
			 se_2.ad_id.focus();
			 return false;
		}
		if ( Validatead_id(se_2.ad_id.value) == false )	{
			alert( "����� ���̵� ��Ȯ�ϰ� �Է��Ͻʽÿ�." );
			se_2.ad_id.focus();
			return false;
		}
		if (se_2.ad_id.value.toLowerCase() == "jboard") {
			 alert("�Է��Ͻ� ���̵�� ����Ͻ� �� �����ϴ�.");
			 se_2.ad_id.value = "";
			 se_2.ad_id.focus();
			 return false;
		}

		strTemp = se_2.ad_pass.value;
		if (Isad_pass(strTemp) == false ) {
			if ( strTemp.length >= 4 && strTemp.length <= 12  ) {
					alert( "���ϰ� �Է��Ͻ� ��й�ȣ�� ��й�ȣ ������ ����� �־�\n ������� ������ �ٸ� ��й�ȣ�� �Է��Ͻñ� �ٶ��ϴ�." );
					}
					else {
					alert( "��й�ȣ�� ��Ȯ�ϰ� �Է��Ͻʽÿ�." );
					}
				se_2.ad_pass.focus();
				return false;
		}			

		strTemp = se_2.ad_pass_again.value;
		if (Isad_pass(strTemp) == false ) {
			 alert( "��й�ȣ Ȯ���� ��Ȯ�ϰ� �Է��Ͻʽÿ�." );
			 se_2.ad_pass_again.focus();
			 return false;
		}		
		if ( se_2.ad_pass.value != se_2.ad_pass_again.value ) {
			 alert( "��й�ȣ�� ��й�ȣ Ȯ���� ��ġ���� �ʽ��ϴ�. ��Ȯ�ϰ� �Է��Ͻʽÿ�." );
			 se_2.ad_pass.focus();
			 return false;
		}


		if (se_2.ad_name.value == "") {
			 alert("[������ �̸�]�� �������ּ���.");
			 se_2.ad_name.focus();
			 return false;
		}


			for(i=0;i<string_1.length;i++)	{
				c = string_1.charAt(i);   
				if(!((c < '0' || c > '9')&&(c < '0' || c > 'z')&&(c < '0' || c > 'Z'))) {
					alert("������ �̸��� �ѱ� �Է¸� �����մϴ�.");        
					se_2.ad_name.value="";
					se_2.ad_name.focus();
					return false;
					}
			} 


		if (se_2.ad_email.value == "") {
			 alert("[������ E-mail]�� �������ּ���.");
			 se_2.ad_email.focus();
			 return false;
		}

			var tempchar = 0;
			for (i=0;i<se_2.ad_email.value.length; i++ ) {
					 temp = se_2.ad_email.value.charAt(i);
				if (temp == "@" || temp ==".") {
					tempchar++; 
				}
			}
			if (tempchar < 2) {
				alert("�̸����� �߸��Է��ϼ̽��ϴ�.");
				se_2.ad_email.focus();
				return false;
			}


		if (se_2.ad_SiteName.value == "") {
			 alert("[����Ʈ(ȸ��)��]�� �������ּ���.");
			 se_2.ad_SiteName.focus();
			 return false;
		}


		if (se_2.si_upload.value == "") {
			 alert("[���ε� ������Ʈ]�� �������ּ���.");
			 se_2.si_upload.focus();
			 return false;
		}

		se_2.action = "setup2_pro.asp";
		se_2.method = "post";

}

// SETUP_2 �� ��

