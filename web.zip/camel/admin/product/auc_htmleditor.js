/**********************************************************************************

	Copyright 2003 (C) Internet Auction Company   All rights reserved.

	Author      : Wonjoo Jang( muzzn@chol.com )

	Description : This program is JScript For Auction HTML Editor

	History     : Last Created on 2003.02.05 ( by Wonjoo Jang )
								Update 2003.05.15 Ÿ����Ʈ ��ũ ������� �ż� ( by Wonjoo Jang )

************************************************************************************/
var is_init = false;
var close_id = null;
var interval_id = null;
var which_color = null;
var selectionObj = null;
var default_source = "<HTML>\n<HEAD>\n<META content='text/html; charset=euc-kr' http-equiv=Content-Type>\n"
+ "<STYLE>\nBODY {FONT-SIZE:12px;FONT-FAMILY:'����';COLOR:#000000}\nTD {FONT-SIZE:12px;FONT-FAMILY:'����';COLOR:#3E3E3E}\n"
+ "</STYLE></HEAD>\n<BODY>\n<DIV>&nbsp;</DIV></BODY>\n</HTML>";

function CSelection()
{
	this.m_selection = null;
	this.GetSelection = get_selection;
	this.PutSelection = put_selection;
}

function get_selection()
{
	if ( this.m_selection != null )
	{ 
		if( this.m_selection.type != "Control" )
		{
			if( ObjAucEditor.document.body.createTextRange().inRange( this.m_selection ) == true )
				this.m_selection.select();
		}
		else
			this.m_selection.select();
	}
}

function put_selection()
{
	this.m_selection = ObjAucEditor.document.selection.createRange();
	this.m_selection.type = ObjAucEditor.document.selection.type;
}

function OnDocumentComplete()
{
	hh=document.all.txtDetail.value

	if (ObjAucEditor.document.readyState != "complete" )
		return true;
	
	if( is_init == false )
	{
		is_init = true;
		document.all.txtDetail.value = document.all.auc_src.value;
		document.all.auc_src.value = "";

		ObjAucEditor.document.designMode="On";
		selectionObj = new CSelection();

		if( document.all.editor_yn[1].checked == true )
		{
			document.all.ObjAucEditor.style.display = "none";
			document.all.auc_toolbar.style.display = "none";
			document.all.txtDetail.style.display = "block";
		}
		else
		{
			if( document.all.txtDetail.value == "" )
				document.all.txtDetail.value = "<DIV>&nbsp;</DIV>";
				
			var src = "";
			if( document.all.txtDetail.value.search( /<html>/gi ) == -1 )
				src = default_source.substring(0,216) + document.all.txtDetail.value + "</BODY>\n</HTML>";
			else
				src = document.all.txtDetail.value;

			ObjAucEditor.document.open("text/html");
			ObjAucEditor.document.write(hh);
			ObjAucEditor.document.close();
			ObjAucEditor.document.oncontextmenu = new Function("return false;");
		}
	}
	return true;
}

function OnChangeEditorYN()
{
	if( document.all.editor_yn[0].checked == true )
	{
		ObjAucEditor.document.open("text/html");
		ObjAucEditor.document.write(document.all.txtDetail.value);
		ObjAucEditor.document.close();
		ObjAucEditor.document.oncontextmenu = new Function("return false;");
		
		document.all.ObjAucEditor.style.display = "block";
		document.all.auc_toolbar.style.display = "block";
		document.all.txtDetail.style.display = "none";
		selectionObj.m_selection = null;
		document.all.ObjAucEditor.focus();
	}
	else if( document.all.editor_yn[1].checked == true )
	{
		document.all.txtDetail.value = ObjAucEditor.document.all.tags("html")[0].outerHTML;
		document.all.ObjAucEditor.style.display = "none";
		document.all.auc_toolbar.style.display = "none";
		document.all.txtDetail.style.display = "block";
		document.all.txtDetail.focus();
	}
}

function presubmit_editor()
{
	var bProc = false;	//��ũ���ѿ� ����
	var szProcURL = "";	//�ܺθ�ũ ����

	if( document.all.editor_yn[0].checked == true ) {
		// �ڵ��� ī�װ����� �ƴҰ�츸 ��ũ����
		if( (typeof(document.forms.next) != "undefined" && document.forms.next.txtAsrtCode.value.substring(0,4) != "0645") ||	//�Ϲݹ�ǰ���
			(typeof(document.forms.prod) != "undefined" && document.forms.prod.Category1.value.substring(0,4) != "0645") ) {	//�Ǹŵ���̹�ǰ���

			var anchorColl = ObjAucEditor.document.body.all.tags("A");
			var len = anchorColl.length;
			var i = 0;
			for( i = 0 ; i < len ; i++ ) {
				if( anchorColl[i].href.indexOf("doortodoor.co.kr") > -1
					|| anchorColl[i].href.indexOf("epost.go.kr") > -1
					|| anchorColl[i].href.indexOf("e-family.co.kr") > -1
					|| anchorColl[i].href.indexOf("hudadaq.com") > -1
					|| anchorColl[i].href.indexOf("samsunghth.co.kr") > -1
					|| anchorColl[i].href.indexOf("hanjin.co.kr") > -1
					|| anchorColl[i].href.indexOf("hyundaiexpress.com") > -1
					|| anchorColl[i].href.indexOf("cjgls.com") > -1
					|| anchorColl[i].href.indexOf("kgbl.co.kr") > -1
					|| anchorColl[i].href.indexOf("ecline.net") > -1
					|| anchorColl[i].href.indexOf("sygls.co.kr") > -1
					|| anchorColl[i].href.indexOf("ajuthankyou.com") > -1
					|| anchorColl[i].href.indexOf("jalogis.com") > -1
					|| anchorColl[i].href.indexOf("kls.co.kr") > -1
					|| anchorColl[i].href.indexOf("kunyoung.com") > -1
					|| anchorColl[i].href.indexOf("yellowcap.co.kr") > -1
					|| anchorColl[i].href.indexOf("119quick.co.kr") > -1 
					|| anchorColl[i].href.indexOf("i8282.co.kr") > -1 
					|| anchorColl[i].href.indexOf("qrs.co.kr") > -1 
					|| anchorColl[i].href.indexOf("dhl.co.kr") > -1 
					|| anchorColl[i].href.indexOf("fedexkorea.co.kr") > -1 )
					continue;
	
				if( anchorColl[i].href.match(/auction./gi) == null && anchorColl[i].href.search( /^mailto:/gi ) == -1 ) {
					anchorColl[i].href = "#";
					szProcURL = anchorColl[i].href;
					bProc = true;
				}
			}
		}
		document.all.txtDetail.value = ObjAucEditor.document.body.innerHTML;
	}
	
	if (document.all.txtDetail.value.replace(/[ \t\n\r]/g, "") == "" 
			|| document.all.txtDetail.value.replace(/[ \t\n\r]/g, "") == "<DIV>&nbsp;</DIV>") {
		alert("�������� �Է��� �ּ���.");
		return false;
	}

	// �ڵ��� ī�װ����� �ƴҰ�츸 ��ũ����
	if( (typeof(document.forms.next) != "undefined" && document.forms.next.txtAsrtCode.value.substring(0,4) != "0645") ||	//�Ϲݹ�ǰ���
		(typeof(document.forms.prod) != "undefined" && document.forms.prod.Category1.value.substring(0,4) != "0645") ) {	//�Ǹŵ���̹�ǰ���
		
		//html�����Է��� ��� ��ũ����
		var bEnd = true;
		var nCurCP = 0, nFindCP = 0, nFindMatchStCP = 0, nFindMatchEndCP = 0, nFindDeleteEndCP = 0;
		var szMatched = "";
		do {
			if( (nFindCP = document.all.txtDetail.value.substr(nCurCP).search( /<a [^>]*/i )) == -1 )
				bEnd = false;
			else {	//a ��ũ ������
				szMatched = document.all.txtDetail.value.substr(nCurCP).match( /<a [^>]*/i )[0];
				if( (nFindMatchStCP = szMatched.search( /http:\/\//i )) > 0 ) {
					if( (nFindMatchEndCP = szMatched.substr(nFindMatchStCP+7).search( /[\/ '"]/i )) > 0 ) {

						if( szMatched.substring(nFindMatchStCP+7, nFindMatchStCP+nFindMatchEndCP+7).indexOf("doortodoor.co.kr") > -1
							|| szMatched.substring(nFindMatchStCP+7, nFindMatchStCP+nFindMatchEndCP+7).indexOf("epost.go.kr") > -1
							|| szMatched.substring(nFindMatchStCP+7, nFindMatchStCP+nFindMatchEndCP+7).indexOf("e-family.co.kr") > -1
							|| szMatched.substring(nFindMatchStCP+7, nFindMatchStCP+nFindMatchEndCP+7).indexOf("hudadaq.com") > -1
							|| szMatched.substring(nFindMatchStCP+7, nFindMatchStCP+nFindMatchEndCP+7).indexOf("samsunghth.co.kr") > -1
							|| szMatched.substring(nFindMatchStCP+7, nFindMatchStCP+nFindMatchEndCP+7).indexOf("hanjin.co.kr") > -1
							|| szMatched.substring(nFindMatchStCP+7, nFindMatchStCP+nFindMatchEndCP+7).indexOf("hyundaiexpress.com") > -1
							|| szMatched.substring(nFindMatchStCP+7, nFindMatchStCP+nFindMatchEndCP+7).indexOf("cjgls.com") > -1
							|| szMatched.substring(nFindMatchStCP+7, nFindMatchStCP+nFindMatchEndCP+7).indexOf("kgbl.co.kr") > -1
							|| szMatched.substring(nFindMatchStCP+7, nFindMatchStCP+nFindMatchEndCP+7).indexOf("ecline.net") > -1
							|| szMatched.substring(nFindMatchStCP+7, nFindMatchStCP+nFindMatchEndCP+7).indexOf("sygls.co.kr") > -1
							|| szMatched.substring(nFindMatchStCP+7, nFindMatchStCP+nFindMatchEndCP+7).indexOf("ajuthankyou.com") > -1
							|| szMatched.substring(nFindMatchStCP+7, nFindMatchStCP+nFindMatchEndCP+7).indexOf("jalogis.com") > -1
							|| szMatched.substring(nFindMatchStCP+7, nFindMatchStCP+nFindMatchEndCP+7).indexOf("kls.co.kr") > -1
							|| szMatched.substring(nFindMatchStCP+7, nFindMatchStCP+nFindMatchEndCP+7).indexOf("kunyoung.com") > -1
							|| szMatched.substring(nFindMatchStCP+7, nFindMatchStCP+nFindMatchEndCP+7).indexOf("yellowcap.co.kr") > -1
							|| szMatched.substring(nFindMatchStCP+7, nFindMatchStCP+nFindMatchEndCP+7).indexOf("119quick.co.kr") > -1 
							|| szMatched.substring(nFindMatchStCP+7, nFindMatchStCP+nFindMatchEndCP+7).indexOf("i8282.co.kr") > -1 
							|| szMatched.substring(nFindMatchStCP+7, nFindMatchStCP+nFindMatchEndCP+7).indexOf("qrs.co.kr") > -1 
							|| szMatched.substring(nFindMatchStCP+7, nFindMatchStCP+nFindMatchEndCP+7).indexOf("dhl.co.kr") > -1 
							|| szMatched.substring(nFindMatchStCP+7, nFindMatchStCP+nFindMatchEndCP+7).indexOf("fedexkorea.co.kr") > -1 ) {
							nCurCP = nCurCP + nFindCP + 1;
							continue;
						}

						if( szMatched.substring(nFindMatchStCP+7, nFindMatchStCP+nFindMatchEndCP+7).search(/auction./gi) == -1 )	{ //���ǵ������̾ƴϴ�.
							szProcURL = szMatched.substring(nFindMatchStCP+7, nFindMatchStCP+nFindMatchEndCP+7);

							bProc = true;
							nFindDeleteEndCP = szMatched.substr(nFindMatchStCP+7).search( /[ '"]/i );
							document.all.txtDetail.value = document.all.txtDetail.value.substr(0, nCurCP+nFindCP+nFindMatchStCP) + "#" +
																							document.all.txtDetail.value.substr( nCurCP+nFindCP+nFindMatchStCP+nFindDeleteEndCP+7 );
						}
					}
				}
				nCurCP = nCurCP + nFindCP + 1;
			}
		}
		while( bEnd );
	}
	
	if( bProc )
		document.all.dellinks_yn.value = "Y";

	return true;
}

function buttonover(td)
{
	td.borderColorDark = "white";
	td.borderColorLight = "gray";
	td.style.cursor = "hand";
}

function buttonout(td)
{
	td.borderColorDark = "#EBEBEB";
	td.borderColorLight = "#EBEBEB";
	td.style.cursor = "auto";
}

function buttondown(td)
{
	td.borderColorDark = "gray";
	td.borderColorLight = "white";
}

function command(obj)
{
	if( selectionObj.m_selection != null )
		selectionObj.GetSelection();

	if( obj.tagName == "SELECT" )
	{
		if( obj.id == "auc_edit" )
		{
			if( obj.options[obj.selectedIndex].text == "��ü����" )
			{
				ObjAucEditor.document.execCommand("SelectAll");
			}
			else if( obj.options[obj.selectedIndex].text == "�߶󳻱�" )
			{
				ObjAucEditor.document.execCommand("Cut");
			}
			else if( obj.options[obj.selectedIndex].text == "�ٿ��ֱ�" )
			{
				ObjAucEditor.document.execCommand("Paste");
			}
			else if( obj.options[obj.selectedIndex].text == "�����" )
			{
				ObjAucEditor.document.execCommand("Delete");
			}
			else if( obj.options[obj.selectedIndex].text == "����" )
			{
				ObjAucEditor.document.execCommand("Copy");
			}
			
			obj.options[0].selected = true;
		}
		else if( obj.id == "auc_font" )
		{
			if( obj.options[obj.selectedIndex].text != "Times" )
			{
				ObjAucEditor.document.execCommand("FontName", null, obj.options[obj.selectedIndex].text);
			}
			else if( obj.options[obj.selectedIndex].text == "Times" )
			{
				ObjAucEditor.document.execCommand("FontName", null, "Times New Roman");
			}
			
			obj.options[0].selected = true;
		} 
		else if( obj.id == "auc_fontsize" )
		{
			ObjAucEditor.document.execCommand("FontSize", null, obj.options[obj.selectedIndex].value);
			
			obj.options[0].selected = true;
		}
	}
	else // ��� TD�� ����.
	{
		if( obj.id == "auc_bold" )
		{
			ObjAucEditor.document.execCommand("Bold");
		}
		else if( obj.id == "auc_italic" )
		{
			ObjAucEditor.document.execCommand("Italic");
		}
		else if( obj.id == "auc_underline" )
		{
			ObjAucEditor.document.execCommand("Underline");
		}
		else if( obj.id == "auc_fontcolor" )
		{
			which_color = obj.id;
			select_color();
		}
		else if( obj.id == "auc_fontbgcolor" )
		{
			which_color = obj.id;
			select_color();
		}
		else if( obj.id == "auc_tablebgcolor" )
		{
			which_color = obj.id;
			select_color();
		}
		else if( obj.id == "auc_left" )
		{
			ObjAucEditor.document.execCommand("JustifyLeft");
		}
		else if( obj.id == "auc_center" )
		{
			ObjAucEditor.document.execCommand("JustifyCenter");
		}
		else if( obj.id == "auc_right" )
		{
			ObjAucEditor.document.execCommand("JustifyRight");
		}
		else if( obj.id == "auc_numlist" )
		{
			ObjAucEditor.document.execCommand("InsertOrderedList");
		}
		else if( obj.id == "auc_itemlist" )
		{
			ObjAucEditor.document.execCommand("InsertUnorderedList");
		}
		else if( obj.id == "auc_outdent" )
		{
			ObjAucEditor.document.execCommand("Outdent");
		}
		else if( obj.id == "auc_indent" )
		{
			ObjAucEditor.document.execCommand("Indent");
		}
		else if( obj.id == "auc_table" )
		{
			make_table();
		}
		else if( obj.id == "auc_newdoc" )
		{
			ObjAucEditor.document.open("text/html");
			ObjAucEditor.document.write(default_source);
			ObjAucEditor.document.close();
			ObjAucEditor.document.oncontextmenu = new Function("return false;");
		}
	}
	buttonout(obj);
	document.all.ObjAucEditor.focus();
}

function make_table()
{
	auc_cellsdiv.style.left = event.clientX + document.body.scrollLeft - 10;
	auc_cellsdiv.style.top = event.clientY + document.body.scrollTop - 180;

	var collTD = auc_cellstable.all;

	for( i=0 ; i < collTD.length ; i++ )
	{
		if( collTD(i).tagName == "TD" && collTD(i).id != "xy_display" )
			collTD(i).bgColor = "";
	}

	start_timeout(document.all.auc_cellstable);

	auc_cellsdiv.style.visibility = "visible";
}

function coloring(td)
{
	var i, rowNum, columnNum;
	rowNum = getRowNum(td);
	columnNum = getColumnNum(td);

	xy_display.innerHTML = columnNum + " * " + (11-rowNum);

	var collTD = auc_cellstable.all;

	for( i=0 ; i < collTD.length ; i++ )
	{
		if( collTD(i).tagName == "TD" && collTD(i).id != "xy_display" 
				&& getRowNum(collTD(i)) >= rowNum && getColumnNum(collTD(i)) <= columnNum )
		{
			collTD(i).bgColor = "orange";
		}
		else
			collTD(i).bgColor = "";
	}
}

function selectXY(td)
{
	var NumRows = 11-getRowNum(td);
	var NumCols = getColumnNum(td);
	var strTable = "<TABLE border=1 cellspacing=0 bordercolor ='black' style='border-collapse:collapse;width:560px'>\n";

	var widthCols = Math.ceil(100/getColumnNum(td))-1;
	var CellAttrs = "width='" + widthCols + "%'";
	
	var i = 0, j = 0;
	for( i = 0 ; i < NumRows ; i++ )
	{
		strTable += "<TR>\n";
		for( j = 0 ; j < NumCols ; j++ )
		{
			strTable += "<TD " + CellAttrs + "><DIV>&nbsp;</DIV></TD>\n";
		}		
		strTable += "</TR>\n";
	}
	strTable += "</TABLE>\n";

	var Range = null;
	if( selectionObj.m_selection != null )
	{
		selectionObj.GetSelection();
		Range = selectionObj.m_selection;
	}
	else
	{
		Range = ObjAucEditor.document.selection.createRange();
		Range.type = ObjAucEditor.document.selection.type;
	}
	
	if( Range.type != "Control" && ObjAucEditor.document.body.createTextRange().inRange( Range ) == true )
		Range.pasteHTML( strTable );
	else if( Range.type == "Control" )
	{
		Range.execCommand("Delete");
		ObjAucEditor.document.selection.createRange().pasteHTML( strTable );
	}

	close_div(auc_cellsdiv);
}

function getRowNum(td)
{
	var gap = td.sourceIndex - base.sourceIndex;

	var row;
	if( Math.round(gap/11) - gap/11 < 0 )
		row = Math.round(gap/11) + 1;
	else
		row = Math.round(gap/11);

	return row;
}

function getColumnNum(td)
{
	return (td.sourceIndex - base.sourceIndex)%11;
}

function close_div(obj)
{
	obj.style.visibility = "hidden";
	clearTimeout(close_id);
}

function select_color()
{
	auc_colordiv.style.left = event.clientX + document.body.scrollLeft - 155;
	auc_colordiv.style.top = event.clientY + document.body.scrollTop - 195;

	var collTD = auc_colortable.all;

	for( i=0 ; i < collTD.length ; i++ )
	{
		if( collTD(i).tagName == "TD" && collTD(i).id != "color_more" )
		{
			collTD(i).borderColor = "";
		}
	}
	
	//close_id=setTimeout('close_div(document.all.auc_colordiv)',1500);
	start_timeout(document.all.auc_colortable);
	
	auc_colordiv.style.visibility = "visible";
}

function color_over(td)
{
	auc_selcolor.bgColor = td.bgColor;
	auc_seltext.innerText = td.bgColor;
}

function color_click(td)
{
		if( selectionObj.m_selection != null )
			selectionObj.GetSelection();
		
		if( which_color == "auc_fontcolor" )
		{
			ObjAucEditor.document.execCommand( "ForeColor", false, td.bgColor );
		}
		else if( which_color == "auc_fontbgcolor" )
		{
			ObjAucEditor.document.execCommand( "BackColor", false, td.bgColor );
		}
		else if( which_color == "auc_tablebgcolor" )
		{
			table_color(td.bgColor);
		}

		which_color = "";
		close_div(auc_colordiv);
}

function table_color(bgColor)
{
	if( ObjAucEditor.document.selection.type == "None" || ObjAucEditor.document.selection.type == "Text" )
	{
		var selectedTD;
		if( (selectedTD = isintd( ObjAucEditor.document.selection.createRange().parentElement() ) ) != null )
		{
			selectedTD.bgColor = bgColor;
		}
	}
	else if( ObjAucEditor.document.selection.type == "Control" )
	{
		if( ObjAucEditor.document.selection.createRange().item(0).tagName == "TABLE" )
		{
			ObjAucEditor.document.selection.createRange().item(0).bgColor = bgColor;
		}
	}
}

function isintd(obj)
{
	var i;
	for( i=0 ; i < 100 ; i++ )
	{
		if( obj.tagName == "TD" )
			return obj;
		else if( obj.tagName == "TABLE" || obj.tagName == "BODY" || obj.tagName == null )
			return null;
		else
			obj = obj.parentElement;
	}
	
	return null;
}

function start_timeout(table)
{
	if( close_id != null )
			clearTimeout(close_id);

	if( table.id == "auc_cellstable" )
	{
		auc_colordiv.style.visibility = "hidden";
		close_id=setTimeout("close_div(document.all.auc_cellsdiv)",1500);
	}
	else if( table.id == "auc_colortable" )
	{
		auc_cellsdiv.style.visibility = "hidden";
		close_id=setTimeout("close_div(document.all.auc_colordiv)",1500);
	}
}

function clear_timeout()
{
	clearTimeout(close_id);
	close_id = null;
}

function deactivate_handler()
{
	if( is_init )
		selectionObj.PutSelection();
}

function force_editmode()
{
	
	if( is_init == false )
		OnDocumentComplete();
	else
		clearInterval( interval_id );
}